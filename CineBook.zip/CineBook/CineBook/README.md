﻿# 🎬 Cine Book - Cinema Management System (Spring Boot + Thymeleaf)

A modern, responsive, web-based Cine Book - Cinema Management System built with **Java Spring Boot**, **Thymeleaf**, and an interactive HTML5/CSS3/JavaScript frontend. 

This project runs **100% locally with zero external database setup required** (using thread-safe in-memory repositories with realistic preloaded demo data). It also provides a centralized validation and business configuration area ready for customization and eventual enterprise database integration.

---

## 📌 Key Highlights

- **Zero Database Dependency**: Out-of-the-box in-memory mock repositories for Movies, Theatres, Showtimes, Users, Bookings, and Payments. Starts instantly without installing or configuring MySQL, PostgreSQL, or MongoDB.
- **Centralized Business & Validation Configuration**: Customize pricing, tax rates, convenience fees, seat layout limits, password rules, email regex, and phone formats from a single configuration file (ValidationConfig.java & alidation-config.js).
- **Rich Interactive Seating Layout**: 40-seat cinema grid with Standard (Rows A–C @ LKR 1,000) and VIP / Premium (Rows D–E @ LKR 1,500) tiers, live price recalculation, convenience fee (LKR 50/ticket), tax (5%), and multi-seat locking.
- **Simulation Payment Gateway**: Test credit/debit cards with formatting, UPI QR simulation, pay-at-counter options, 1-click test fill presets, and built-in decline/retry failure testing.
- **Printable E-Ticket**: Instant confirmation e-ticket with barcode & QR code simulation, booking reference ID, movie/hall metadata, and one-click browser print support (window.print()).
- **Role-Based Access Control**: Clean interceptor architecture protecting customer bookings/profile routes and admin management portals (CUSTOMER, ADMIN, CASHIER, MANAGER, SUPPORT).
- **Modern Responsive Dark Theme**: Cinematic dark UI across desktop and mobile devices with zero intrusive JavaScript lert() popups.

---

## 📋 System Requirements

- **Java Development Kit (JDK)**: Java 17 or higher (tested and verified with Java 17, 21, and 25 LTS).
- **Maven**: Maven 3.8+ (The project includes the Maven Wrapper mvnw / mvnw.cmd, so you do not need Maven installed globally).
- **Web Browser**: Any modern browser (Chrome, Edge, Firefox, Safari).

---

## 🚀 Quick Start Guide

### 1. Clone or Extract the Project
Extract the project archive to your local directory:
`ash
cd Cine Book
`

### 2. Run the Application

#### On Windows (Command Prompt / PowerShell):
`cmd
mvnw.cmd spring-boot:run
`

#### On Linux / macOS:
`ash
chmod +x ./mvnw
./mvnw spring-boot:run
`

### 3. Build Executable JAR (Optional)
`ash
./mvnw clean package -DskipTests
java -jar target/Cine Book-0.0.1-SNAPSHOT.jar
`

### 4. Access the Web Application
Open your browser and navigate to:
`
http://localhost:8080
`

---

## 👥 Preloaded Demo Accounts

The system comes preloaded with active user accounts for all core cinema roles. You can log in using either the email or username:

| Role | Email | Username | Password | Access & Features |
| :--- | :--- | :--- | :--- | :--- |
| **Customer** | customer@moviebook.com | customer | Password123 | Browse movies, select showtimes & seats, mock payment, view bookings, print e-tickets, profile editing. |
| **Admin** | dmin@moviebook.com | dmin | Admin123! | Full admin dashboard, add/edit movies, manage theatres, add/edit users, view revenue & metrics. |
| **Cashier** | cashier@moviebook.com | cashier | Cashier123! | Box office counter booking, barcode search, ticket issuance, and refunds. |
| **Manager** | manager@moviebook.com | manager | Manager123! | Theatre performance reports, revenue analytics, and occupancy charts. |
| **Support** | support@moviebook.com | support | Support123! | Customer service ticketing and booking resolution. |

> 💡 **Tip**: On the /login page, click the **⚡ Fill Customer Demo** or **⚡ Fill Admin Demo** buttons to autofill credentials in 1 click!

---

## 🎬 Preloaded Movies & Theatres

### Movies (8 Featured Titles with Posters)
1. **The Last Journey** (Action/Adventure &bull; 8.5/10)
2. **Avatar: The Way of Water** (Sci-Fi/Action &bull; 7.8/10)
3. **Spider-Man: Across the Spider-Verse** (Animation/Action &bull; 8.7/10)
4. **Oppenheimer** (Biography/Drama &bull; 8.9/10)
5. **The Dark Knight** (Action/Crime &bull; 9.0/10)
6. **Inception** (Sci-Fi/Thriller &bull; 8.8/10)
7. **Interstellar** (Sci-Fi/Adventure &bull; 8.7/10)
8. **Dune: Part Two** (Sci-Fi/Adventure &bull; 8.6/10)

### Cities & Theatres
- **Colombo**: Liberty Cinema Hall (Screen 1 & 2), Majestic Cineplex (Screen 1 & 2)
- **Kandy**: Kandy City Cinema
- **Jaffna**: Jaffna Central Cinema
- **Galle**: Galle Heritage Screen

---

## ⚙️ Centralized Validation & Business Configuration

All business rules, pricing tiers, and input validation patterns can be inspected and updated in two centralized files without modifying core controller logic:

### 1. Backend: ValidationConfig.java
**Location**: src/main/java/com/moviebooking/moviebookingsystem/config/ValidationConfig.java

`java
// Pricing & Fees
public static final double STANDARD_SEAT_PRICE = 1000.00; // Rows A-C
public static final double PREMIUM_SEAT_PRICE  = 1500.00; // Rows D-E
public static final double CONVENIENCE_FEE_PER_TICKET = 50.00;
public static final double TAX_RATE = 0.05; // 5%

// Seat Limits & Lock Timeout
public static final int MAX_SEATS_PER_BOOKING = 6;
public static final int MIN_SEATS_PER_BOOKING = 1;
public static final long SEAT_LOCK_DURATION_MS = 5 * 60 * 1000; // 5 minutes

// Validation Patterns
public static final String EMAIL_REGEX = ^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$;
public static final String MOBILE_REGEX = ^(?:\\+94|0)?7[0-9]{8}$; // 10 digits
public static final int PASSWORD_MIN_LENGTH = 8;
`

### 2. Frontend: alidation-config.js
**Location**: src/main/resources/static/js/validation-config.js

Synchronized rules and calculations running client-side for immediate responsive feedback:
- ValidationRules.isValidEmail(email)
- ValidationRules.isValidMobile(phone)
- ValidationRules.isValidPassword(password)
- ValidationRules.calculateOrder(selectedSeats) (calculates subtotal, convenience fee, tax, and grand total)

---

## 🗄️ Database Integration Guide (When Ready)

When you are ready to transition from in-memory mock data to an external relational database (e.g. MySQL or PostgreSQL), follow these steps:

1. **Add Database Dependencies** in pom.xml:
   `xml
   <dependency>
       <groupId>org.springframework.boot</groupId>
       <artifactId>spring-boot-starter-data-jpa</artifactId>
   </dependency>
   <dependency>
       <groupId>com.mysql</groupId>
       <artifactId>mysql-connector-j</artifactId>
       <scope>runtime</scope>
   </dependency>
   `

2. **Configure Database Connection** in src/main/resources/application.properties:
   `properties
   spring.datasource.url=jdbc:mysql://localhost:3306/movie_booking_db?useSSL=false&serverTimezone=UTC
   spring.datasource.username=root
   spring.datasource.password=your_password
   spring.jpa.hibernate.ddl-auto=update
   spring.jpa.show-sql=true
   `

3. **Convert Models to JPA Entities**:
   Add @Entity, @Table, @Id, and @GeneratedValue(strategy = GenerationType.IDENTITY) to classes in com.moviebooking.moviebookingsystem.model.

4. **Change Repositories to Spring Data JPA**:
   Update MovieRepository, UserRepository, BookingRepository, etc., to extend JpaRepository<Entity, Long>. The service layer and controllers are already cleanly abstracted and will continue to work seamlessly!

---

## 🧪 Automated Testing

Run the included unit and integration tests:
`ash
./mvnw test
`
**Test Coverage**:
- contextLoads: Verifies Spring Boot ApplicationContext, component wiring, and repository injection.
- 	estPreloadedMovies: Verifies at least 8 movies are loaded with valid IDs, metadata, and poster URLs.
- 	estDemoUsersExist: Verifies Customer and Admin credentials.
- 	estValidationConfigPricingAndRules: Validates pricing tiers (A1 @ 1000, D1 @ 1500), email/mobile regex, and seat rules.
- 	estBookingMultiSeatOperations: Tests multi-seat booking and seat reservation checks.

---

## 📂 Project Structure

`
Cine Book/
├── pom.xml                                  # Maven dependencies & build configuration
├── mvnw / mvnw.cmd                          # Maven wrapper executables
├── src/
│   ├── main/
│   │   ├── java/com/moviebooking/moviebookingsystem/
│   │   │   ├── CineManageApplication.java
│   │   │   ├── config/
│   │   │   │   ├── AuthInterceptor.java     # Route protection & role enforcement
│   │   │   │   ├── ValidationConfig.java    # Central business & validation rules
│   │   │   │   └── WebMvcConfig.java        # Spring MVC interceptor registry
│   │   │   ├── controller/                  # User, Movie, Booking, Payment, Admin controllers
│   │   │   ├── model/                       # Movie, Theatre, Showtime, Booking, User, Payment
│   │   │   ├── repository/                  # In-memory thread-safe repositories preloaded with demo data
│   │   │   └── service/                     # UserService, BookingService, EmailService (simulation mode)
│   │   └── resources/
│   │       ├── application.properties       # Server port & config
│   │       ├── static/
│   │       │   ├── css/style.css            # Dark cinema theme & print styles
│   │       │   ├── js/validation-config.js  # Frontend validation & price calculation
│   │       │   └── images/                  # 8 Movie posters & visual assets
│   │       └── templates/                   # Thymeleaf templates (login, signup, movies, booking, payment, admin...)
│   └── test/                                # JUnit 5 & Spring Boot test suite
├── README.md                                # Complete system documentation
└── CHANGELOG.md                             # Comprehensive breakdown of all fixes
`

---

## 📜 License & Acknowledgements

Developed as an educational and production-ready reference Web-Based Cine Book - Cinema Management System. Built with Spring Boot and Thymeleaf.
