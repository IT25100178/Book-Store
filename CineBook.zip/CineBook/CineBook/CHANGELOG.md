﻿# 📜 CHANGELOG - Cine Book - Cinema Management System Fixes & Improvements

This changelog outlines all bugs, architectural deficiencies, and runtime errors discovered in the original codebase, along with the detailed resolutions implemented across all modules.

---

## [1.0.0] - 2026-09-18

### 1. Architectural & Database Decoupling
- **Decoupled External Databases**: Removed assumptions of an external MySQL/PostgreSQL server and configured the entire project to run on clean, thread-safe, in-memory repositories with mock data.
- **Resolved ID Collision Crash**: Previously, MovieRepository preloaded 4 movies with IDs 1..4, and CineManageApplication ran a CommandLineRunner inserting 4 more movies with IDs 1..4. Unified all 8 movies directly into MovieRepository with unique IDs 1..8 and matching poster images.
- **Eliminated Duplicate & Competing Repositories**: Standardized MovieRepository, TheatreRepository, ShowtimeRepository, UserRepository, BookingRepository, and PaymentRepository to provide consistent CRUD and query interfaces.

### 2. Validation & Business Configuration (Requirement 3)
- **Centralized Backend Rules (ValidationConfig.java)**:
  - Centralized rules for standard seats (LKR 1,000), VIP/Premium seats (LKR 1,500), convenience fee (LKR 50/ticket), and tax rate (5%).
  - Configurable email regex, allowed email domains list, 10-digit mobile pattern, password length/complexity rules, and single-booking seat limits (1 to 6 seats).
- **Synchronized Frontend Rules (alidation-config.js)**:
  - Implemented client-side validation methods matching ValidationConfig.java.
  - Added dynamic order breakdown calculator calculating subtotal, convenience fee, tax, and grand total.

### 3. Login & Authentication
- **Dual Email/Username Support**: Enabled users to log in using either their registered email address or their username.
- **Login Redirect Memory**: Fixed the login form to remember the target URL (?redirect=...) so users who try to book tickets without being logged in are redirected back to their booking step after logging in.
- **Remember-Me Simulation**: Added Remember-Me checkbox and state persistence.
- **Password Visibility Toggle**: Added eye icon toggle allowing users to view or hide their password.
- **1-Click Demo Fill**: Added test helper buttons on the login page for instant 1-click login as Customer (customer@moviebook.com / Password123) or Admin (dmin@moviebook.com / Admin123!).

### 4. Registration & Forgot Password
- **Password Confirmation**: Added a confirmPassword field to signup.html and verified password matching on both client and server before user creation.
- **Mobile Number Validation**: Enforced 10-digit format with live feedback.
- **Password Strength Indicator**: Added a visual password strength bar (Weak, Moderate, Strong).
- **Safe Simulated Forgot Password Flow**: Replaced the previous broken flow that depended on external SMTP credentials. Simulated reset code generation and direct password update with success banners.
- **Email Service Safety**: Updated EmailService.java to operate in safe simulation mode with console logging, preventing runtime crashes when SMTP host is unconfigured.

### 5. Routing, Security & Session Management
- **AuthInterceptor.java**: Implemented an HTTP interceptor to protect:
  - Customer routes: /booking/**, /payment/**, /profile/**, /my-bookings (redirects unauthenticated users to /login with return destination).
  - Admin/Staff routes: /admin/**, /cashier/**, /theatre/**, /marketing/**, /owner/** (enforces role check, returns 403 / redirect if unauthorized).
- **Navbar Session Awareness**: Updated navigation across all templates (index.html, movies.html, ooking.html, payment.html, my-bookings.html, profile.html) to dynamically display user's name, profile link, and logout button when logged in, or Login/Signup buttons when logged out.
- **Global Error Handling**: Integrated with Spring Boot's BasicErrorController and created a polished error.html page handling 404, 403, 500 errors with friendly messages and home navigation.

### 6. Movies Catalog & Showtime Cascade
- **Dynamic Catalog**: Replaced hardcoded static movie HTML in index.html and movies.html with dynamic Thymeleaf iteration from MovieRepository.
- **Search, Filter & Sorting**:
  - Live search by movie title and genre.
  - Multi-criteria filtering by Genre (Action, Sci-Fi, Animation, Drama), Language (English, Sinhala, Tamil), and Rating.
  - Sorting options: Rating (High to Low), Title (A to Z), Release Date.
- **Cascading Booking Flow**: Rebuilt /booking with cascading dropdowns:
  - Selecting a City filters available Theatres.
  - Selecting a Theatre updates available Dates and Showtimes.
  - Displays movie poster, synopsis, hall name, and show details.

### 7. Interactive Seating Layout & Booking Engine
- **Visual 40-Seat Cinema Grid**:
  - Rows A–C: Standard Seating (LKR 1,000).
  - Rows D–E: Premium VIP Seating (LKR 1,500).
- **Seat Status Display**: Available (Grey/Dark), Selected (Red), and Booked/Sold Out (Dark Disabled).
- **Multi-Seat Selection**: Users can select up to 6 seats per transaction.
- **Asynchronous Seat Availability**: Added /api/booked-seats endpoint to dynamically fetch already booked seats for the selected movie, theatre, date, and showtime.
- **Real-Time Order Summary**: Sticky sidebar computes and displays ticket count, seat tags, subtotal, convenience fee, tax, and grand total in real-time.
- **Eliminated Obtrusive JavaScript lert()**: Replaced all native alert popups with smooth inline banner notifications.

### 8. Mock Payment Gateway & Printable E-Tickets
- **Simulation Payment Gateway (payment.html)**:
  - Payment method selector: Credit/Debit Card, UPI / QR Wallet, and Cash at Counter.
  - Card number automatic spacing (groups of 4 digits) and expiry date auto-slash (MM / YY).
  - One-click testing presets: Fill Demo Card (Success) and Fill Failing Card (Test Decline).
  - Visual 10-minute session countdown timer.
  - Error banner handling simulated decline and retry flows.
- **Printable Cinema E-Ticket (payment-success.html)**:
  - Designed an authentic cinema e-ticket layout with Movie details, Hall, Date, Time, Seats, Total, and Reference Code (BK-2026-XXXX).
  - Barcode and QR code simulation graphics.
  - Browser print button calling window.print() with custom @media print CSS rules that suppress navbars and footers for a clean paper or PDF printout.

### 9. Booking Management & Cancellation
- **User-Specific Bookings (my-bookings.html)**: Shows only the logged-in customer's bookings (matched by email or username).
- **Status Badges**: CONFIRMED (Green), PAYMENT PENDING (Yellow), CANCELLED (Red).
- **Action Buttons**: View/Print E-Ticket, Resume Pending Payment, and Cancel Booking.
- **Cancellation & Seat Release**: Allows cancelling tickets, updating booking status to CANCELLED, releasing seats, and displaying a success confirmation notice.

### 10. Customer Profile & Admin Management
- **Customer Profile (profile.html)**: Redesigned to match the dark cinema aesthetic; allows customers to view their username and role, and update their Full Name, Email, Telephone (10 digits), and Date of Birth with live validation.
- **Admin Management**: Ensured /admin/movies, /admin/theatres, and /admin/users support full create/read/update/delete operations with proper validation.

---

## 🧪 Verification & Build Status
- **Test Suite**: 5 unit & integration tests executed via JUnit 5 (mvnw test) &mdash; **BUILD SUCCESS, 0 failures, 0 errors**.
- **Packaging**: Full executable JAR packaged via mvnw clean package &mdash; **BUILD SUCCESS, 0 errors**.
