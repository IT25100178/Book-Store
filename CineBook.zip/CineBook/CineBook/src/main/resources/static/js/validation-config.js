/**
 * ============================================================================
 * CLIENT-SIDE VALIDATION & BUSINESS CONFIGURATION
 * ============================================================================
 * Mirror of ValidationConfig.java for client-side forms, real-time feedback,
 * interactive seat layout calculations, and payment mock validations.
 */
const CineManageingValidation = {
    emailRegex: /^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/,
    allowedEmailDomains: [], // Optional allowed domains list, e.g. ["gmail.com"]

    mobileRegex: /^(?:\+94|0)?7[0-9]{8}$/,
    mobileExactDigits: 10,

    passwordMinLength: 8,
    passwordMaxLength: 64,
    requireLetters: true,
    requireDigits: true,
    requireSpecialChar: false,

    maxSeatsPerBooking: 6,
    minSeatsPerBooking: 1,

    pricing: {
        standardSeat: 1000.00,
        premiumSeat: 1500.00,
        convenienceFeePerTicket: 50.00,
        taxRate: 0.05
    },

    payment: {
        cardRegex: /^[0-9]{16}$/,
        cvvRegex: /^[0-9]{3}$/,
        upiRegex: /^[a-zA-Z0-9.\-_]{2,49}@[a-zA-Z]{2,}$/
    },

    // Validation Methods
    validateEmail: function(email) {
        if (!email) return { valid: false, message: "Email is required." };
        const trimmed = email.trim();
        if (!this.emailRegex.test(trimmed)) {
            return { valid: false, message: "Please enter a valid email address (e.g. user@example.com)." };
        }
        if (this.allowedEmailDomains.length > 0) {
            const domain = trimmed.split("@")[1].toLowerCase();
            if (!this.allowedEmailDomains.includes(domain)) {
                return { valid: false, message: `Email domain must be one of: ${this.allowedEmailDomains.join(", ")}` };
            }
        }
        return { valid: true };
    },

    validateMobile: function(mobile) {
        if (!mobile) return { valid: false, message: "Mobile number is required." };
        const cleaned = mobile.trim().replace(/[^0-9]/g, "");
        if (cleaned.length !== 10 && cleaned.length !== 11) {
            return { valid: false, message: "Mobile number must be a valid 10-digit number (e.g. 0771234567)." };
        }
        return { valid: true };
    },

    validatePassword: function(password) {
        if (!password) return { valid: false, message: "Password is required." };
        if (password.length < this.passwordMinLength) {
            return { valid: false, message: `Password must be at least ${this.passwordMinLength} characters long.` };
        }
        if (this.requireLetters && !/[A-Za-z]/.test(password)) {
            return { valid: false, message: "Password must contain at least one letter." };
        }
        if (this.requireDigits && !/\d/.test(password)) {
            return { valid: false, message: "Password must contain at least one number." };
        }
        if (this.requireSpecialChar && !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
            return { valid: false, message: "Password must contain at least one special character." };
        }
        return { valid: true };
    },

    calculateBookingTotals: function(selectedSeats) {
        if (!selectedSeats || selectedSeats.length === 0) {
            return { count: 0, subtotal: 0, convenienceFee: 0, tax: 0, total: 0 };
        }
        let subtotal = 0;
        selectedSeats.forEach(seat => {
            // Rows D and E are Premium (VIP)
            if (seat.startsWith("D") || seat.startsWith("E")) {
                subtotal += this.pricing.premiumSeat;
            } else {
                subtotal += this.pricing.standardSeat;
            }
        });
        const convenienceFee = selectedSeats.length * this.pricing.convenienceFeePerTicket;
        const tax = (subtotal + convenienceFee) * this.pricing.taxRate;
        const total = Math.round((subtotal + convenienceFee + tax) * 100) / 100;
        return {
            count: selectedSeats.length,
            subtotal: subtotal,
            convenienceFee: convenienceFee,
            tax: Math.round(tax * 100) / 100,
            total: total
        };
    }
};

// Expose globally
if (typeof window !== "undefined") {
    window.CineManageingValidation = CineManageingValidation;
}
