package com.cinebook.cinebookingsystem.controller;

import com.cinebook.cinebookingsystem.service.MovieService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    private final MovieService movieService;

    public HomeController(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping("/")
    public String home(
            @RequestParam(required = false) String login,
            @RequestParam(required = false) String logout,
            @RequestParam(required = false) String error,
            Model model) {

        model.addAttribute("movies", movieService.getAllMovies());
        if (login != null) model.addAttribute("loginSuccess", true);
        if (logout != null) model.addAttribute("logoutSuccess", true);
        if (error != null) model.addAttribute("errorMessage", error);

        return "index";
    }
}