package com.cinebook.cinebookingsystem.controller;

import com.cinebook.cinebookingsystem.model.Showtime;
import com.cinebook.cinebookingsystem.service.BookingService;
import com.cinebook.cinebookingsystem.service.ShowtimeService;
import com.cinebook.cinebookingsystem.service.TheatreService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class TheatreManagerController {

    private final TheatreService theatreService;
    private final ShowtimeService showtimeService;
    private final BookingService bookingService;


    // ================= CONSTRUCTOR =================

    public TheatreManagerController(
            TheatreService theatreService,
            ShowtimeService showtimeService,
            BookingService bookingService) {

        this.theatreService = theatreService;
        this.showtimeService = showtimeService;
        this.bookingService = bookingService;
    }


    // ================= DASHBOARD =================

    @GetMapping("/theatre-manager")
    public String dashboard(Model model) {

        model.addAttribute(
                "theatreCount",
                theatreService.getAllTheatres().size()
        );

        model.addAttribute(
                "theatres",
                theatreService.getAllTheatres()
        );

        model.addAttribute(
                "showtimes",
                showtimeService.getAllShowtimes()
        );

        model.addAttribute(
                "showtimeCount",
                showtimeService.getAllShowtimes().size()
        );

        return "theatre/dashboard";
    }


    // ================= SHOWTIME LIST =================

    @GetMapping("/theatre-manager/showtimes")
    public String showtimes(Model model) {

        model.addAttribute(
                "showtimes",
                showtimeService.getAllShowtimes()
        );

        return "theatre/showtimes";
    }


    // ================= ADD SHOWTIME PAGE =================

    @GetMapping("/theatre-manager/showtimes/add")
    public String addShowtimePage(Model model) {

        model.addAttribute(
                "showtime",
                new Showtime()
        );

        return "theatre/add-showtime";
    }


    // ================= ADD SHOWTIME =================

    @PostMapping("/theatre-manager/showtimes/add")
    public String addShowtime(
            @ModelAttribute Showtime showtime) {

        showtimeService.addShowtime(showtime);

        return "redirect:/theatre-manager/showtimes";
    }


    // ================= EDIT SHOWTIME PAGE =================

    @GetMapping("/theatre-manager/showtimes/edit")
    public String editShowtimePage(
            @RequestParam Long id,
            Model model) {

        Showtime showtime =
                showtimeService.findShowtimeById(id);

        if (showtime == null) {
            return "redirect:/theatre-manager/showtimes";
        }

        model.addAttribute(
                "showtime",
                showtime
        );

        return "theatre/edit-showtime";
    }


    // ================= UPDATE SHOWTIME =================

    @PostMapping("/theatre-manager/showtimes/edit")
    public String updateShowtime(
            @ModelAttribute Showtime showtime) {

        showtimeService.updateShowtime(showtime);

        return "redirect:/theatre-manager/showtimes";
    }


    // ================= DELETE SHOWTIME =================

    @PostMapping("/theatre-manager/showtimes/delete")
    public String deleteShowtime(
            @RequestParam Long id) {

        showtimeService.deleteShowtime(id);

        return "redirect:/theatre-manager/showtimes";
    }


    // ================= VIEW BOOKINGS =================

    @GetMapping("/theatre-manager/bookings")
    public String bookings(Model model) {

        model.addAttribute(
                "bookings",
                bookingService.getAllBookings()
        );

        return "theatre/bookings";
    }


    // ================= THEATRE DETAILS =================

    @GetMapping("/theatre-manager/theatre-details")
    public String theatreDetails(Model model) {

        model.addAttribute(
                "theatres",
                theatreService.getAllTheatres()
        );

        return "theatre/theatre-details";
    }

}