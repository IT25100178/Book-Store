package com.cinebook.cinebookingsystem.controller;

import com.cinebook.cinebookingsystem.config.ValidationConfig;
import com.cinebook.cinebookingsystem.model.Booking;
import com.cinebook.cinebookingsystem.model.Movie;
import com.cinebook.cinebookingsystem.model.Showtime;
import com.cinebook.cinebookingsystem.model.Theatre;
import com.cinebook.cinebookingsystem.model.User;
import com.cinebook.cinebookingsystem.service.BookingService;
import com.cinebook.cinebookingsystem.service.MovieService;
import com.cinebook.cinebookingsystem.service.ShowtimeService;
import com.cinebook.cinebookingsystem.service.TheatreService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Controller
public class BookingController {

    private final BookingService bookingService;
    private final MovieService movieService;
    private final ShowtimeService showtimeService;
    private final TheatreService theatreService;

    public BookingController(
            BookingService bookingService,
            MovieService movieService,
            ShowtimeService showtimeService,
            TheatreService theatreService) {
        this.bookingService = bookingService;
        this.movieService = movieService;
        this.showtimeService = showtimeService;
        this.theatreService = theatreService;
    }

    // ==========================================
    // BOOKING PAGE
    // ==========================================
    @GetMapping("/booking")
    public String bookingPage(
            @RequestParam(required = false) Long movieId,
            @RequestParam(required = false) String movieTitle,
            @RequestParam(required = false) String city,
            @RequestParam(required = false) String theatre,
            @RequestParam(required = false) String date,
            @RequestParam(required = false) String showTime,
            HttpSession session,
            Model model) {

        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            String target = "/booking" + (movieId != null ? "?movieId=" + movieId : "");
            return "redirect:/login?redirect=" + target + "&error=Please log in to book tickets.";
        }

        Booking booking = new Booking();
        booking.setMovieId(movieId);
        booking.setMovieTitle(movieTitle);
        booking.setCity(city);
        booking.setTheatre(theatre);
        booking.setDate(date);
        booking.setShowTime(showTime);
        booking.setCustomerName(user.getName());
        booking.setUserEmail(user.getEmail());
        booking.setTelephone(user.getTelephone());

        // Load Movies
        List<Movie> movies = movieService.getAllMovies();
        if (movieId != null && (movieTitle == null || movieTitle.isEmpty())) {
            Movie m = movieService.findMovieById(movieId);
            if (m != null) booking.setMovieTitle(m.getTitle());
        }

        // Load Theatres & Cities
        List<Theatre> theatres = theatreService.getAllTheatres();
        Set<String> cities = theatres.stream()
                .map(Theatre::getCity)
                .filter(Objects::nonNull)
                .collect(Collectors.toCollection(TreeSet::new));

        // Load Showtimes
        List<Showtime> showtimes = showtimeService.getAllShowtimes();

        // Get currently booked seats for preselection if show parameters exist
        List<String> bookedSeats = new ArrayList<>();
        if (movieId != null && theatre != null && date != null && showTime != null) {
            bookedSeats = bookingService.getBookedSeatsForShow(movieId, theatre, date, showTime);
        }

        // Available dates (today + next 6 days)
        LocalDate today = LocalDate.now();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        List<String> availableDates = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            availableDates.add(today.plusDays(i).format(dtf));
        }

        model.addAttribute("booking", booking);
        model.addAttribute("movies", movies);
        model.addAttribute("theatres", theatres);
        model.addAttribute("cities", cities);
        model.addAttribute("showtimes", showtimes);
        model.addAttribute("bookedSeats", bookedSeats);
        model.addAttribute("availableDates", availableDates);
        model.addAttribute("minDate", today.format(dtf));

        return "booking";
    }

    // ==========================================
    // CREATE / CONFIRM SEAT LOCK & GO TO PAYMENT
    // ==========================================
    @PostMapping("/booking")
    public String createBooking(
            @ModelAttribute Booking booking,
            HttpSession session,
            Model model) {

        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return "redirect:/login?redirect=/booking&error=Please log in to complete your booking.";
        }

        booking.setCustomerName(user.getName());
        booking.setUserEmail(user.getEmail());
        booking.setTelephone(user.getTelephone());

        // Validation: Required selections
        if (booking.getMovieId() == null ||
            booking.getTheatre() == null || booking.getTheatre().trim().isEmpty() ||
            booking.getDate() == null || booking.getDate().trim().isEmpty() ||
            booking.getShowTime() == null || booking.getShowTime().trim().isEmpty() ||
            booking.getSeatNumber() == null || booking.getSeatNumber().trim().isEmpty()) {

            return reloadBookingFormWithError(booking, "Please select all required details: Movie, City, Theatre, Date, Show Time, and at least one Seat.", model);
        }

        // Validate past date
        try {
            LocalDate selectedDate = LocalDate.parse(booking.getDate().trim());
            if (selectedDate.isBefore(LocalDate.now())) {
                return reloadBookingFormWithError(booking, "Cannot book shows for past dates. Please select today or an upcoming date.", model);
            }
        } catch (Exception e) {
            return reloadBookingFormWithError(booking, "Invalid date selected.", model);
        }

        // Validate seat limits
        List<String> seats = Arrays.stream(booking.getSeatNumber().split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());

        if (seats.isEmpty()) {
            return reloadBookingFormWithError(booking, "Please select at least one seat.", model);
        }

        if (seats.size() > ValidationConfig.MAX_SEATS_PER_BOOKING) {
            return reloadBookingFormWithError(booking, "You can select a maximum of " + ValidationConfig.MAX_SEATS_PER_BOOKING + " seats per booking.", model);
        }

        // Check if any seat is already booked
        if (bookingService.isAnySeatBooked(booking.getSeatNumber(), booking.getMovieId(), booking.getTheatre(), booking.getDate(), booking.getShowTime())) {
            return reloadBookingFormWithError(booking, "One or more of your selected seats are no longer available. Please select different seats.", model);
        }

        // Calculate Pricing dynamically on server
        double subtotal = 0.0;
        for (String seat : seats) {
            if (seat.startsWith("D") || seat.startsWith("E")) {
                subtotal += ValidationConfig.PREMIUM_SEAT_PRICE;
            } else {
                subtotal += ValidationConfig.STANDARD_SEAT_PRICE;
            }
        }
        double convenienceFee = seats.size() * ValidationConfig.CONVENIENCE_FEE_PER_TICKET;
        double tax = Math.round((subtotal + convenienceFee) * ValidationConfig.TAX_RATE * 100.0) / 100.0;
        double total = Math.round((subtotal + convenienceFee + tax) * 100.0) / 100.0;

        booking.setSeatCount(seats.size());
        booking.setSubtotal(subtotal);
        booking.setConvenienceFee(convenienceFee);
        booking.setTax(tax);
        booking.setPrice(total);

        // Ensure movie title is set
        if (booking.getMovieTitle() == null || booking.getMovieTitle().isEmpty()) {
            Movie m = movieService.findMovieById(booking.getMovieId());
            if (m != null) booking.setMovieTitle(m.getTitle());
        }

        boolean created = bookingService.createBooking(booking);
        if (!created) {
            return reloadBookingFormWithError(booking, "Seat reservation failed. The selected seat may have just been locked by another guest.", model);
        }

        // Redirect to demo payment page with the locked booking ID
        return "redirect:/payment?bookingId=" + booking.getId();
    }

    private String reloadBookingFormWithError(Booking booking, String errorMessage, Model model) {
        model.addAttribute("booking", booking);
        model.addAttribute("movies", movieService.getAllMovies());
        model.addAttribute("theatres", theatreService.getAllTheatres());

        Set<String> cities = theatreService.getAllTheatres().stream()
                .map(Theatre::getCity)
                .filter(Objects::nonNull)
                .collect(Collectors.toCollection(TreeSet::new));
        model.addAttribute("cities", cities);
        model.addAttribute("showtimes", showtimeService.getAllShowtimes());

        List<String> booked = new ArrayList<>();
        if (booking.getMovieId() != null && booking.getTheatre() != null && booking.getDate() != null && booking.getShowTime() != null) {
            booked = bookingService.getBookedSeatsForShow(booking.getMovieId(), booking.getTheatre(), booking.getDate(), booking.getShowTime());
        }
        model.addAttribute("bookedSeats", booked);
        model.addAttribute("error", errorMessage);
        return "booking";
    }

    // ==========================================
    // REST API FOR DYNAMIC SEAT STATUS LOOKUP
    // ==========================================
    @GetMapping("/api/booked-seats")
    @ResponseBody
    public List<String> getBookedSeats(
            @RequestParam Long movieId,
            @RequestParam String theatre,
            @RequestParam String date,
            @RequestParam String showTime) {
        return bookingService.getBookedSeatsForShow(movieId, theatre, date, showTime);
    }

    // ==========================================
    // MY BOOKINGS (FILTERED TO CURRENT USER)
    // ==========================================
    @GetMapping("/my-bookings")
    public String myBookings(
            @RequestParam(required = false) String cancelled,
            HttpSession session,
            Model model) {

        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return "redirect:/login?redirect=/my-bookings&error=Please log in to view your bookings.";
        }

        List<Booking> userBookings;
        if ("ADMIN".equalsIgnoreCase(user.getRole())) {
            userBookings = bookingService.getAllBookings();
        } else {
            userBookings = bookingService.getBookingsByUser(user.getEmail());
        }

        // Sort latest bookings first
        userBookings.sort((b1, b2) -> Long.compare(b2.getId() != null ? b2.getId() : 0, b1.getId() != null ? b1.getId() : 0));

        model.addAttribute("bookings", userBookings);
        if (cancelled != null) {
            model.addAttribute("success", "Your booking has been successfully cancelled and seats have been released.");
        }
        return "my-bookings";
    }

    // ==========================================
    // CANCEL BOOKING (DEMO CANCELLATION)
    // ==========================================
    @GetMapping("/booking/cancel")
    public String cancelBooking(
            @RequestParam Long bookingId,
            HttpSession session) {

        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return "redirect:/login";
        }

        Booking booking = bookingService.findBookingById(bookingId);
        if (booking != null) {
            // Ensure only the booking owner or an admin can cancel
            if ("ADMIN".equalsIgnoreCase(user.getRole()) ||
                (booking.getUserEmail() != null && booking.getUserEmail().equalsIgnoreCase(user.getEmail()))) {
                bookingService.cancelBooking(bookingId);
            }
        }

        return "redirect:/my-bookings?cancelled=true";
    }
}