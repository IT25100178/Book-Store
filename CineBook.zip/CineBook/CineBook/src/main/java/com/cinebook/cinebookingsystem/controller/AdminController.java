package com.cinebook.cinebookingsystem.controller;

import com.cinebook.cinebookingsystem.model.User;
import com.cinebook.cinebookingsystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private UserService userService;

    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    // Admin verifies the Cinema Owner here
    @PostMapping("/verify-owner/{ownerId}")
    public ResponseEntity<String> verifyCinemaOwner(@PathVariable Long ownerId) {
        boolean success = userService.verifyOwner(ownerId);
        if (success) {
            return ResponseEntity.ok("Cinema Owner verification successful.");
        }
        return ResponseEntity.badRequest().body("Owner not found or already verified.");
    }
}