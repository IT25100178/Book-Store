package com.cinebook.cinebookingsystem.service;

import com.cinebook.cinebookingsystem.model.Showtime;
import com.cinebook.cinebookingsystem.repository.ShowtimeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShowtimeService {

    private final ShowtimeRepository showtimeRepository;

    public ShowtimeService(
            ShowtimeRepository showtimeRepository) {

        this.showtimeRepository = showtimeRepository;
    }


    // ================= GET ALL SHOWTIMES =================

    public List<Showtime> getAllShowtimes() {

        return showtimeRepository.findAll();
    }


    // ================= FIND SHOWTIME =================

    public Showtime findShowtimeById(Long id) {

        return showtimeRepository.findById(id);
    }


    // ================= ADD SHOWTIME =================

    public void addShowtime(Showtime showtime) {

        showtimeRepository.save(showtime);
    }


    // ================= UPDATE SHOWTIME =================

    public boolean updateShowtime(Showtime showtime) {

        return showtimeRepository.updateShowtime(showtime);
    }


    // ================= DELETE SHOWTIME =================

    public boolean deleteShowtime(Long id) {

        return showtimeRepository.deleteById(id);
    }
}