package com.cinebook.cinebookingsystem.service;

import com.cinebook.cinebookingsystem.model.Theatre;
import com.cinebook.cinebookingsystem.repository.TheatreRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TheatreService {

    private final TheatreRepository theatreRepository;

    public TheatreService(TheatreRepository theatreRepository) {
        this.theatreRepository = theatreRepository;
    }


    // =========================
    // GET ALL THEATRES
    // =========================

    public List<Theatre> getAllTheatres() {

        return theatreRepository.findAll();
    }


    // =========================
    // FIND THEATRE BY ID
    // =========================

    public Theatre findTheatreById(Long id) {

        return theatreRepository.findById(id);
    }


    // =========================
    // SAVE THEATRE
    // =========================

    public void saveTheatre(Theatre theatre) {

        theatreRepository.save(theatre);
    }


    // =========================
    // ADD THEATRE
    // =========================

    public void addTheatre(Theatre theatre) {

        theatreRepository.save(theatre);
    }


    // =========================
    // UPDATE THEATRE
    // =========================

    public boolean updateTheatre(Theatre theatre) {

        return theatreRepository.updateTheatre(theatre);
    }


    // =========================
    // DELETE THEATRE
    // =========================

    public boolean deleteTheatre(Long id) {

        return theatreRepository.deleteById(id);
    }
}