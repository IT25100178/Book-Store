package com.cinebook.cinebookingsystem.controller;

import com.cinebook.cinebookingsystem.model.Booking;
import com.cinebook.cinebookingsystem.model.Payment;
import com.cinebook.cinebookingsystem.service.BookingService;
import com.cinebook.cinebookingsystem.service.CashierService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CashierController {

    private final CashierService cashierService;
    private final BookingService bookingService;

    public CashierController(
            CashierService cashierService,
            BookingService bookingService) {

        this.cashierService = cashierService;
        this.bookingService = bookingService;
    }


    // ==============================
    // CASHIER DASHBOARD
    // ==============================

    @GetMapping("/cashier")
    public String cashierDashboard(Model model) {

        model.addAttribute(
                "payments",
                cashierService.getAllPayments()
        );

        return "cashier/dashboard";
    }


    // ==============================
    // COUNTER BOOKING PAGE
    // ==============================

    @GetMapping("/cashier/counter-booking")
    public String counterBookingPage() {

        return "cashier/counter-booking";
    }


    // ==============================
    // CREATE COUNTER BOOKING
    // ==============================

    @PostMapping("/cashier/counter-booking")
    public String createCounterBooking(
            @RequestParam Long movieId,
            @RequestParam String movieTitle,
            @RequestParam String customerName,
            @RequestParam String telephone,
            @RequestParam String theatre,
            @RequestParam String date,
            @RequestParam String showTime,
            @RequestParam String seatNumber,
            @RequestParam double price,
            Model model) {

        // Cashier validation required by the assignment
        if (customerName == null || !customerName.trim().matches("[a-zA-Z ]{2,50}")) {
            model.addAttribute("error", "Customer name must contain letters and spaces only.");
            return "cashier/counter-booking";
        }
        if (telephone == null || !telephone.trim().matches("\\d{10}")) {
            model.addAttribute("error", "Telephone number must contain exactly 10 digits.");
            return "cashier/counter-booking";
        }
        if (movieId == null || movieTitle == null || movieTitle.trim().isEmpty()
                || theatre == null || theatre.trim().isEmpty()
                || date == null || date.trim().isEmpty()
                || showTime == null || showTime.trim().isEmpty()
                || seatNumber == null || seatNumber.trim().isEmpty()) {
            model.addAttribute("error", "Please complete all booking fields.");
            return "cashier/counter-booking";
        }
        if (price <= 0) {
            model.addAttribute("error", "Booking amount must be greater than 0.");
            return "cashier/counter-booking";
        }

        Booking booking = new Booking();
        booking.setMovieId(movieId);
        booking.setMovieTitle(movieTitle.trim());
        booking.setCustomerName(customerName.trim());
        booking.setTelephone(telephone.trim());
        booking.setTheatre(theatre.trim());
        booking.setDate(date.trim());
        booking.setShowTime(showTime.trim());
        booking.setSeatNumber(seatNumber.trim().toUpperCase());
        booking.setPrice(price);

        boolean created = bookingService.createBooking(booking);

        if (!created) {
            model.addAttribute("error", "Sorry! This seat is already booked for this show.");
            return "cashier/counter-booking";
        }

        model.addAttribute("booking", booking);
        return "cashier/counter-booking";
    }

    // ==============================
    // PAYMENT PAGE
    // ==============================

    @GetMapping("/cashier/payment")
    public String paymentPage(

            @RequestParam(required = false)
            Long bookingId,

            @RequestParam(required = false)
            Double amount,

            Model model) {

        model.addAttribute(
                "bookingId",
                bookingId
        );

        model.addAttribute(
                "amount",
                amount
        );


        return "cashier/payment";
    }


    // ==============================
    // PROCESS PAYMENT
    // ==============================

    @PostMapping("/cashier/payment")
    public String processPayment(

            @RequestParam Long bookingId,

            @RequestParam double amount,

            @RequestParam String paymentMethod,

            Model model) {


        Payment payment =
                cashierService.processPayment(
                        bookingId,
                        amount,
                        paymentMethod
                );


        model.addAttribute(
                "payment",
                payment
        );


        // Find booking details

        for (Booking booking :
                bookingService.getAllBookings()) {

            if (booking.getId() != null
                    && booking.getId()
                    .equals(bookingId)) {

                model.addAttribute(
                        "booking",
                        booking
                );

                break;
            }
        }


        return "cashier/ticket";
    }


    // ==============================
    // REFUND PAGE
    // ==============================

    @GetMapping("/cashier/refund")
    public String refundPage(Model model) {

        return "cashier/refund";
    }


    // ==============================
    // PROCESS REFUND
    // ==============================

    @PostMapping("/cashier/refund")
    public String processRefund(

            @RequestParam Long bookingId,

            Model model) {


        boolean refunded =
                cashierService.processRefund(
                        bookingId
                );


        if (refunded) {

            model.addAttribute(
                    "success",
                    "Refund processed successfully."
            );

        } else {

            model.addAttribute(
                    "error",
                    "Refund failed. Payment not found or already refunded."
            );
        }


        return "cashier/refund";
    }


    // ==============================
    // TRANSACTIONS
    // ==============================

    @GetMapping("/cashier/transactions")
    public String transactions(Model model) {

        model.addAttribute(
                "payments",
                cashierService.getAllPayments()
        );

        return "cashier/transactions";
    }


    // ==============================
    // SEARCH BOOKING
    // ==============================

    @GetMapping("/cashier/search-booking")
    public String searchBooking(

            @RequestParam(required = false)
            Long bookingId,

            Model model) {


        if (bookingId != null) {

            Booking foundBooking = null;


            for (Booking booking :
                    bookingService.getAllBookings()) {

                if (booking.getId() != null
                        && booking.getId()
                        .equals(bookingId)) {

                    foundBooking = booking;

                    break;
                }
            }


            if (foundBooking != null) {

                model.addAttribute(
                        "booking",
                        foundBooking
                );


                Payment payment =
                        cashierService.getPaymentByBookingId(
                                bookingId
                        );


                model.addAttribute(
                        "payment",
                        payment
                );

            } else {

                model.addAttribute(
                        "error",
                        "Booking not found."
                );
            }
        }


        return "cashier/search-booking";
    }
}