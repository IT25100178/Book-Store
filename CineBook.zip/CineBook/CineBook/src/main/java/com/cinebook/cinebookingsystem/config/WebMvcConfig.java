package com.cinebook.cinebookingsystem.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private final AuthInterceptor authInterceptor;

    public WebMvcConfig(AuthInterceptor authInterceptor) {
        this.authInterceptor = authInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authInterceptor)
                .addPathPatterns(
                        "/admin/**",
                        "/admin",
                        "/theatre-manager/**",
                        "/theatre-manager",
                        "/cashier/**",
                        "/cashier",
                        "/support/**",
                        "/support",
                        "/marketing/**",
                        "/marketing",
                        "/owner/**",
                        "/owner",
                        "/booking/**",
                        "/booking",
                        "/payment/**",
                        "/payment",
                        "/profile/**",
                        "/profile",
                        "/my-bookings/**",
                        "/my-bookings"
                )
                .excludePathPatterns(
                        "/css/**",
                        "/js/**",
                        "/images/**",
                        "/static/**",
                        "/login",
                        "/signup",
                        "/forgot-password",
                        "/error"
                );
    }
}
