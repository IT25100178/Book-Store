package com.cinebook.cinebookingsystem.controller;

import com.cinebook.cinebookingsystem.model.Movie;
import com.cinebook.cinebookingsystem.model.Showtime;
import com.cinebook.cinebookingsystem.service.MovieService;
import com.cinebook.cinebookingsystem.service.ShowtimeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class MovieController {

    private final MovieService movieService;
    private final ShowtimeService showtimeService;

    public MovieController(
            MovieService movieService,
            ShowtimeService showtimeService) {
        this.movieService = movieService;
        this.showtimeService = showtimeService;
    }

    // ==========================================
    // CUSTOMER - VIEW ALL MOVIES (SEARCH, FILTER, SORT)
    // ==========================================
    @GetMapping("/movies")
    public String getMovies(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String genre,
            @RequestParam(required = false) String language,
            @RequestParam(required = false) Double minRating,
            @RequestParam(required = false, defaultValue = "rating") String sortBy,
            @RequestParam(required = false, defaultValue = "desc") String sortDir,
            Model model) {

        List<Movie> movies = movieService.getAllMovies();

        // Keyword search (title, genre, or description)
        if (search != null && !search.trim().isEmpty()) {
            String keyword = search.trim().toLowerCase();
            movies = movies.stream()
                    .filter(m -> (m.getTitle() != null && m.getTitle().toLowerCase().contains(keyword)) ||
                                 (m.getGenre() != null && m.getGenre().toLowerCase().contains(keyword)) ||
                                 (m.getDescription() != null && m.getDescription().toLowerCase().contains(keyword)))
                    .collect(Collectors.toList());
        }

        // Genre filter
        if (genre != null && !genre.trim().isEmpty() && !"ALL".equalsIgnoreCase(genre.trim())) {
            String gFilter = genre.trim().toLowerCase();
            movies = movies.stream()
                    .filter(m -> m.getGenre() != null && m.getGenre().toLowerCase().contains(gFilter))
                    .collect(Collectors.toList());
        }

        // Language filter
        if (language != null && !language.trim().isEmpty() && !"ALL".equalsIgnoreCase(language.trim())) {
            String lFilter = language.trim().toLowerCase();
            movies = movies.stream()
                    .filter(m -> m.getLanguage() != null && m.getLanguage().toLowerCase().contains(lFilter))
                    .collect(Collectors.toList());
        }

        // Minimum Rating filter
        if (minRating != null && minRating > 0) {
            movies = movies.stream()
                    .filter(m -> m.getRating() >= minRating)
                    .collect(Collectors.toList());
        }

        // Sorting
        Comparator<Movie> comparator;
        if ("title".equalsIgnoreCase(sortBy)) {
            comparator = Comparator.comparing(m -> m.getTitle() != null ? m.getTitle().toLowerCase() : "");
        } else if ("releaseDate".equalsIgnoreCase(sortBy)) {
            comparator = Comparator.comparing(m -> m.getReleaseDate() != null ? m.getReleaseDate() : "");
        } else {
            // Default: rating
            comparator = Comparator.comparingDouble(Movie::getRating);
        }

        if ("desc".equalsIgnoreCase(sortDir)) {
            comparator = comparator.reversed();
        }

        movies = movies.stream().sorted(comparator).collect(Collectors.toList());

        model.addAttribute("movies", movies);
        model.addAttribute("search", search);
        model.addAttribute("genre", genre);
        model.addAttribute("language", language);
        model.addAttribute("minRating", minRating);
        model.addAttribute("sortBy", sortBy);
        model.addAttribute("sortDir", sortDir);

        return "movies";
    }

    // ==========================================
    // CUSTOMER - VIEW MOVIE DETAILS
    // ==========================================
    @GetMapping("/movie-details")
    public String movieDetails(
            @RequestParam(value = "id", required = false) Long id,
            @RequestParam(value = "movieId", required = false) Long movieId,
            Model model) {

        Long targetId = id != null ? id : movieId;
        if (targetId == null) {
            return "redirect:/movies";
        }

        Movie movie = movieService.findMovieById(targetId);
        if (movie == null) {
            return "redirect:/movies";
        }

        List<Showtime> showtimes = showtimeService.getAllShowtimes().stream()
                .filter(s -> s.getMovieId() != null && s.getMovieId().equals(targetId))
                .collect(Collectors.toList());

        model.addAttribute("movie", movie);
        model.addAttribute("showtimes", showtimes);

        return "movie-details";
    }

    // ==========================================
    // CUSTOMER - VIEW MOVIE SHOWTIMES
    // ==========================================
    @GetMapping("/movie-showtimes")
    public String movieShowtimes(
            @RequestParam Long movieId,
            Model model) {

        Movie movie = movieService.findMovieById(movieId);
        if (movie == null) {
            return "redirect:/movies";
        }

        List<Showtime> allShowtimes = showtimeService.getAllShowtimes();
        List<Showtime> movieShowtimes = allShowtimes.stream()
                .filter(showtime -> showtime.getMovieId() != null && showtime.getMovieId().equals(movieId))
                .collect(Collectors.toList());

        model.addAttribute("movie", movie);
        model.addAttribute("showtimes", movieShowtimes);

        return "movie-showtimes";
    }
}