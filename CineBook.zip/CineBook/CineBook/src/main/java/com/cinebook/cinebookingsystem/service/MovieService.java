package com.cinebook.cinebookingsystem.service;

import com.cinebook.cinebookingsystem.model.Movie;
import com.cinebook.cinebookingsystem.repository.MovieRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieService {

    private final MovieRepository movieRepository;

    public MovieService(MovieRepository movieRepository) {
        this.movieRepository = movieRepository;
    }


    // =========================
    // GET ALL MOVIES
    // =========================

    public List<Movie> getAllMovies() {

        return movieRepository.findAll();
    }


    // =========================
    // FIND MOVIE BY ID
    // =========================

    public Movie findMovieById(Long id) {

        return movieRepository.findById(id);
    }


    // =========================
    // SAVE MOVIE
    // =========================

    public void saveMovie(Movie movie) {

        movieRepository.save(movie);
    }


    // =========================
    // ADD MOVIE
    // =========================

    public void addMovie(Movie movie) {

        movieRepository.save(movie);
    }


    // =========================
    // UPDATE MOVIE
    // =========================

    public boolean updateMovie(Movie movie) {

        return movieRepository.updateMovie(movie);
    }


    // =========================
    // DELETE MOVIE
    // =========================

    public boolean deleteMovie(Long id) {

        return movieRepository.deleteById(id);
    }
}