package com.cinebook.cinebookingsystem.model;

public class Payment {

    private Long id;
    private Long bookingId;
    private double amount;
    private String paymentMethod;
    private String status;

    // Constructor
    public Payment() {
    }

    // Get ID
    public Long getId() {
        return id;
    }

    // Set ID
    public void setId(Long id) {
        this.id = id;
    }

    // Get Booking ID
    public Long getBookingId() {
        return bookingId;
    }

    // Set Booking ID
    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    // Get Amount
    public double getAmount() {
        return amount;
    }

    // Set Amount
    public void setAmount(double amount) {
        this.amount = amount;
    }

    // Get Payment Method
    public String getPaymentMethod() {
        return paymentMethod;
    }

    // Set Payment Method
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    // Get Status
    public String getStatus() {
        return status;
    }

    // Set Status
    public void setStatus(String status) {
        this.status = status;
    }
}