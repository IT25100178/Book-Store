package com.cinebook.cinebookingsystem.controller;

import com.cinebook.cinebookingsystem.model.User;
import com.cinebook.cinebookingsystem.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/admin")
public class AdminOwnerController {
    private final UserService userService;

    public AdminOwnerController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/owners")
    public String owners(Model model, HttpSession session) {
        User admin = (User) session.getAttribute("loggedInUser");
        if (admin == null || !"ADMIN".equalsIgnoreCase(admin.getRole())) {
            return "redirect:/login?redirect=/admin/owners";
        }

        List<User> owners = userService.getAllUsers().stream()
                .filter(u -> "OWNER".equalsIgnoreCase(u.getRole()))
                .collect(Collectors.toList());

        model.addAttribute("owners", owners);
        return "admin/owners";
    }

    @PostMapping("/owners/verify")
    public String verifyOwner(@RequestParam Long ownerId, HttpSession session) {
        User admin = (User) session.getAttribute("loggedInUser");
        if (admin == null || !"ADMIN".equalsIgnoreCase(admin.getRole())) {
            return "redirect:/login?redirect=/admin/owners";
        }
        userService.verifyOwner(ownerId);
        return "redirect:/admin/owners";
    }
}
