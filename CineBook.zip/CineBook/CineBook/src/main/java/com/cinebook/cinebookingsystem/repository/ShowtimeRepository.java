package com.cinebook.cinebookingsystem.repository;

import com.cinebook.cinebookingsystem.model.Showtime;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Repository
public class ShowtimeRepository {

    private final List<Showtime> showtimes = new ArrayList<>();

    public ShowtimeRepository() {
        initDefaultShowtimes();
    }

    private void initDefaultShowtimes() {
        // Base dates starting from current day
        LocalDate today = LocalDate.now();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String d0 = today.format(dtf);
        String d1 = today.plusDays(1).format(dtf);
        String d2 = today.plusDays(2).format(dtf);
        String d3 = today.plusDays(3).format(dtf);

        long id = 1L;

        // Movie 1 - The Last Journey
        showtimes.add(new Showtime(id++, 1L, "The Last Journey", "Liberty Cinema Hall", "Colombo", d0, "10:30 AM", 180, 172));
        showtimes.add(new Showtime(id++, 1L, "The Last Journey", "Liberty Cinema Hall", "Colombo", d0, "05:00 PM", 180, 165));
        showtimes.add(new Showtime(id++, 1L, "The Last Journey", "Liberty Cinema Hall", "Colombo", d1, "08:30 PM", 180, 180));
        showtimes.add(new Showtime(id++, 1L, "The Last Journey", "KCC Cineplex", "Kandy", d1, "01:45 PM", 150, 142));
        showtimes.add(new Showtime(id++, 1L, "The Last Journey", "SLIIT Cinema Hall", "Jaffna", d2, "06:30 PM", 160, 150));

        // Movie 2 - Midnight Story
        showtimes.add(new Showtime(id++, 2L, "Midnight Story", "Liberty Cinema Hall", "Colombo", d0, "08:30 PM", 180, 170));
        showtimes.add(new Showtime(id++, 2L, "Midnight Story", "KCC Cineplex", "Kandy", d0, "05:00 PM", 150, 145));
        showtimes.add(new Showtime(id++, 2L, "Midnight Story", "Galle Marine Multiplex", "Galle", d1, "08:30 PM", 140, 135));

        // Movie 3 - Galaxy War
        showtimes.add(new Showtime(id++, 3L, "Galaxy War", "Liberty Cinema Hall", "Colombo", d0, "01:45 PM", 180, 160));
        showtimes.add(new Showtime(id++, 3L, "Galaxy War", "KCC Cineplex", "Kandy", d1, "08:30 PM", 150, 140));
        showtimes.add(new Showtime(id++, 3L, "Galaxy War", "Galle Marine Multiplex", "Galle", d2, "05:00 PM", 140, 138));

        // Movie 4 - Love Again
        showtimes.add(new Showtime(id++, 4L, "Love Again", "Liberty Cinema Hall", "Colombo", d1, "05:00 PM", 180, 175));
        showtimes.add(new Showtime(id++, 4L, "Love Again", "KCC Cineplex", "Kandy", d0, "10:30 AM", 150, 148));
        showtimes.add(new Showtime(id++, 4L, "Love Again", "SLIIT Cinema Hall", "Jaffna", d1, "01:45 PM", 160, 155));

        // Movie 5 - Sarthar
        showtimes.add(new Showtime(id++, 5L, "Sarthar", "SLIIT Cinema Hall", "Jaffna", d0, "06:30 PM", 160, 152));
        showtimes.add(new Showtime(id++, 5L, "Sarthar", "Liberty Cinema Hall", "Colombo", d1, "01:45 PM", 180, 170));
        showtimes.add(new Showtime(id++, 5L, "Sarthar", "KCC Cineplex", "Kandy", d2, "05:00 PM", 150, 145));

        // Movie 6 - Mandaadi
        showtimes.add(new Showtime(id++, 6L, "Mandaadi", "Liberty Cinema Hall", "Colombo", d0, "10:30 AM", 180, 168));
        showtimes.add(new Showtime(id++, 6L, "Mandaadi", "KCC Cineplex", "Kandy", d1, "01:45 PM", 150, 140));
        showtimes.add(new Showtime(id++, 6L, "Mandaadi", "Galle Marine Multiplex", "Galle", d0, "05:00 PM", 140, 130));

        // Movie 7 - Immortal
        showtimes.add(new Showtime(id++, 7L, "Immortal", "Liberty Cinema Hall", "Colombo", d2, "08:30 PM", 180, 178));
        showtimes.add(new Showtime(id++, 7L, "Immortal", "Galle Marine Multiplex", "Galle", d1, "05:00 PM", 140, 136));

        // Movie 8 - DC Chronicles
        showtimes.add(new Showtime(id++, 8L, "DC Chronicles", "Liberty Cinema Hall", "Colombo", d0, "05:00 PM", 180, 162));
        showtimes.add(new Showtime(id++, 8L, "DC Chronicles", "KCC Cineplex", "Kandy", d2, "08:30 PM", 150, 144));
        showtimes.add(new Showtime(id++, 8L, "DC Chronicles", "SLIIT Cinema Hall", "Jaffna", d3, "06:30 PM", 160, 158));
    }

    public List<Showtime> findAll() {
        return new ArrayList<>(showtimes);
    }

    public synchronized void save(Showtime showtime) {
        if (showtime.getId() == null) {
            long maxId = showtimes.stream().mapToLong(s -> s.getId() != null ? s.getId() : 0L).max().orElse(0L);
            showtime.setId(maxId + 1);
        } else {
            for (int i = 0; i < showtimes.size(); i++) {
                if (showtimes.get(i).getId().equals(showtime.getId())) {
                    showtimes.set(i, showtime);
                    return;
                }
            }
        }
        showtimes.add(showtime);
    }

    public Showtime findById(Long id) {
        if (id == null) return null;
        for (Showtime showtime : showtimes) {
            if (showtime.getId() != null && showtime.getId().equals(id)) {
                return showtime;
            }
        }
        return null;
    }

    public synchronized boolean updateShowtime(Showtime updatedShowtime) {
        if (updatedShowtime == null || updatedShowtime.getId() == null) return false;
        Showtime existing = findById(updatedShowtime.getId());
        if (existing != null) {
            existing.setMovieId(updatedShowtime.getMovieId());
            existing.setMovieTitle(updatedShowtime.getMovieTitle());
            existing.setTheatre(updatedShowtime.getTheatre());
            existing.setCity(updatedShowtime.getCity());
            existing.setHallName(updatedShowtime.getHallName());
            existing.setDate(updatedShowtime.getDate());
            existing.setShowTime(updatedShowtime.getShowTime());
            existing.setTotalSeats(updatedShowtime.getTotalSeats());
            existing.setAvailableSeats(updatedShowtime.getAvailableSeats());
            existing.setStandardPrice(updatedShowtime.getStandardPrice());
            existing.setPremiumPrice(updatedShowtime.getPremiumPrice());
            return true;
        }
        return false;
    }

    public synchronized boolean deleteById(Long id) {
        if (id == null) return false;
        return showtimes.removeIf(showtime -> showtime.getId() != null && showtime.getId().equals(id));
    }
}