package com.cinebook.cinebookingsystem.config;

import com.cinebook.cinebookingsystem.model.User;
import jakarta.annotation.Nonnull;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(@Nonnull HttpServletRequest request,
                             @Nonnull HttpServletResponse response,
                             @Nonnull Object handler) throws Exception {

        String uri = request.getRequestURI();

        if (uri.startsWith("/css/") || uri.startsWith("/js/") || uri.startsWith("/images/")
                || uri.startsWith("/login") || uri.startsWith("/signup")
                || uri.startsWith("/forgot-password") || uri.startsWith("/error")) {
            return true;
        }

        HttpSession session = request.getSession(false);
        User user = session == null ? null : (User) session.getAttribute("loggedInUser");

        boolean adminRoute = uri.equals("/admin") || uri.startsWith("/admin/") || uri.startsWith("/api/admin");
        boolean ownerRoute = uri.equals("/owner") || uri.startsWith("/owner/") || uri.startsWith("/api/owner");

        if (adminRoute) {
            if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN, "Admin access required.");
                return false;
            }
        }

        if (ownerRoute) {
            if (user == null || !"OWNER".equalsIgnoreCase(user.getRole())) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN, "Cinema Owner access required.");
                return false;
            }
            if (!user.isVerified()) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN,
                        "Cinema Owner account is pending Admin verification.");
                return false;
            }
        }

        return true;
    }
}
