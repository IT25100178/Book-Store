package com.cinebook.cinebookingsystem.service;

import com.cinebook.cinebookingsystem.config.ValidationConfig;
import com.cinebook.cinebookingsystem.model.Booking;
import com.cinebook.cinebookingsystem.repository.BookingRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;

    public BookingService(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public List<Booking> getBookingsByUser(String email) {
        return bookingRepository.findByUserEmail(email);
    }

    public Booking findBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    public Booking findBookingByReference(String ref) {
        return bookingRepository.findByReference(ref);
    }

    public boolean isSeatBooked(String seatNumber, Long movieId, String theatre, String date, String showTime) {
        return bookingRepository.isSeatBooked(seatNumber, movieId, theatre, date, showTime);
    }

    public boolean isAnySeatBooked(String seatCsv, Long movieId, String theatre, String date, String showTime) {
        return bookingRepository.isAnySeatBooked(seatCsv, movieId, theatre, date, showTime);
    }

    public List<String> getBookedSeatsForShow(Long movieId, String theatre, String date, String showTime) {
        return bookingRepository.getBookedSeatsForShow(movieId, theatre, date, showTime);
    }

    public boolean createBooking(Booking booking) {
        if (booking == null || booking.getSeatNumber() == null || booking.getSeatNumber().trim().isEmpty()) {
            return false;
        }

        // Check if any of the selected seats are already locked or booked
        if (bookingRepository.isAnySeatBooked(
                booking.getSeatNumber(),
                booking.getMovieId(),
                booking.getTheatre(),
                booking.getDate(),
                booking.getShowTime())) {
            return false;
        }

        // Lock the seats for the configured duration (5 minutes)
        booking.setStatus("LOCKED");
        booking.setLockExpiryTime(System.currentTimeMillis() + ValidationConfig.SEAT_LOCK_DURATION_MS);

        bookingRepository.save(booking);
        return true;
    }

    public boolean cancelBooking(Long bookingId) {
        return bookingRepository.cancelBooking(bookingId);
    }
}