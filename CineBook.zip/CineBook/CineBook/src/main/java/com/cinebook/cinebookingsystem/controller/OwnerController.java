package com.cinebook.cinebookingsystem.controller;

import com.cinebook.cinebookingsystem.model.Booking;
import com.cinebook.cinebookingsystem.model.Payment;
import com.cinebook.cinebookingsystem.model.Theatre;
import com.cinebook.cinebookingsystem.model.User;
import com.cinebook.cinebookingsystem.config.ValidationConfig;
import com.cinebook.cinebookingsystem.service.BookingService;
import com.cinebook.cinebookingsystem.service.CashierService;
import com.cinebook.cinebookingsystem.service.MovieService;
import com.cinebook.cinebookingsystem.service.TheatreService;
import com.cinebook.cinebookingsystem.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
public class OwnerController {

    private final BookingService bookingService;
    private final CashierService cashierService;
    private final MovieService movieService;
    private final TheatreService theatreService;
    private final UserService userService;

    public OwnerController(BookingService bookingService,
                           CashierService cashierService,
                           MovieService movieService,
                           TheatreService theatreService,
                           UserService userService) {
        this.bookingService = bookingService;
        this.cashierService = cashierService;
        this.movieService = movieService;
        this.theatreService = theatreService;
        this.userService = userService;
    }

    @GetMapping("/owner")
    public String dashboard(Model model, HttpSession session) {
        User owner = currentOwner(session);
        if (owner == null) return "redirect:/login?redirect=/owner";

        List<Booking> bookings = bookingService.getAllBookings();
        List<Payment> payments = cashierService.getAllPayments();

        model.addAttribute("owner", owner);
        model.addAttribute("totalRevenue", totalRevenue(payments));
        model.addAttribute("totalBookings", bookings.size());
        model.addAttribute("paidBookings", bookings.stream().filter(b -> "PAID".equalsIgnoreCase(b.getStatus())).count());
        model.addAttribute("activeMovies", movieService.getAllMovies().size());
        model.addAttribute("totalTheatres", theatreService.getAllTheatres().size());
        model.addAttribute("totalUsers", userService.getAllUsers().size());

        List<MovieRevenue> topMovies = topMoviesByRevenue(bookings, 5);
        double max = topMovies.stream().mapToDouble(MovieRevenue::getRevenue).max().orElse(1);
        model.addAttribute("topMovies", topMovies);
        model.addAttribute("maxTopRevenue", max);
        return "owner/dashboard";
    }

    @GetMapping("/owner/theatres")
    public String theatres(Model model, HttpSession session,
                           @RequestParam(required = false) String success,
                           @RequestParam(required = false) String error) {
        User owner = currentOwner(session);
        if (owner == null) return "redirect:/login?redirect=/owner/theatres";
        model.addAttribute("owner", owner);
        model.addAttribute("theatres", theatreService.getAllTheatres());
        model.addAttribute("success", success);
        model.addAttribute("error", error);
        return "owner/theatres";
    }

    @GetMapping("/owner/theatres/create")
    public String createTheatrePage(Model model, HttpSession session) {
        if (currentOwner(session) == null) return "redirect:/login?redirect=/owner/theatres/create";
        model.addAttribute("theatre", new Theatre());
        return "owner/theatre-form";
    }

    @PostMapping("/owner/theatres/create")
    public String createTheatre(@ModelAttribute Theatre theatre, Model model, HttpSession session) {
        if (currentOwner(session) == null) return "redirect:/login?redirect=/owner/theatres/create";

        String validationError = validateTheatre(theatre, null);
        if (validationError != null) {
            model.addAttribute("theatre", theatre);
            model.addAttribute("error", validationError);
            return "owner/theatre-form";
        }

        theatreService.addTheatre(theatre);
        return "redirect:/owner/theatres?success=Theatre created successfully";
    }

    @GetMapping("/owner/theatres/edit")
    public String editTheatrePage(@RequestParam Long id, Model model, HttpSession session) {
        if (currentOwner(session) == null) return "redirect:/login?redirect=/owner/theatres";
        Theatre theatre = theatreService.findTheatreById(id);
        if (theatre == null) return "redirect:/owner/theatres?error=Theatre not found";
        model.addAttribute("theatre", theatre);
        return "owner/theatre-form";
    }

    @PostMapping("/owner/theatres/edit")
    public String updateTheatre(@ModelAttribute Theatre theatre, Model model, HttpSession session) {
        if (currentOwner(session) == null) return "redirect:/login?redirect=/owner/theatres";

        if (theatre == null || theatre.getId() == null || theatreService.findTheatreById(theatre.getId()) == null) {
            return "redirect:/owner/theatres?error=Theatre not found";
        }

        String validationError = validateTheatre(theatre, theatre.getId());
        if (validationError != null) {
            model.addAttribute("theatre", theatre);
            model.addAttribute("error", validationError);
            return "owner/theatre-form";
        }

        if (!theatreService.updateTheatre(theatre)) {
            return "redirect:/owner/theatres?error=Unable to update theatre";
        }
        return "redirect:/owner/theatres?success=Theatre updated successfully";
    }

    @PostMapping("/owner/theatres/delete")
    public String deleteTheatre(@RequestParam Long id, HttpSession session) {
        if (currentOwner(session) == null) return "redirect:/login?redirect=/owner/theatres";
        if (!theatreService.deleteTheatre(id)) {
            return "redirect:/owner/theatres?error=Theatre not found";
        }
        return "redirect:/owner/theatres?success=Theatre deleted successfully";
    }

    @GetMapping("/owner/revenue")
    public String revenue(Model model, HttpSession session) {
        User owner = currentOwner(session);
        if (owner == null) return "redirect:/login?redirect=/owner/revenue";

        List<Booking> bookings = bookingService.getAllBookings();
        List<Payment> payments = cashierService.getAllPayments();
        List<MovieRevenue> movieRevenues = topMoviesByRevenue(bookings, Integer.MAX_VALUE);
        double maxRevenue = movieRevenues.stream().mapToDouble(MovieRevenue::getRevenue).max().orElse(1);

        model.addAttribute("owner", owner);
        model.addAttribute("totalRevenue", totalRevenue(payments));
        model.addAttribute("movieRevenues", movieRevenues);
        model.addAttribute("maxRevenue", maxRevenue);
        return "owner/revenue";
    }

    @GetMapping("/owner/sales-report")
    public String salesReport(Model model, HttpSession session) {
        User owner = currentOwner(session);
        if (owner == null) return "redirect:/login?redirect=/owner/sales-report";

        List<Booking> bookings = bookingService.getAllBookings();
        model.addAttribute("owner", owner);
        model.addAttribute("bookings", bookings);
        model.addAttribute("totalSales", bookings.size());
        model.addAttribute("totalValue", bookings.stream().mapToDouble(Booking::getPrice).sum());
        return "owner/sales-report";
    }

    @GetMapping("/owner/booking-summary")
    public String bookingSummary(Model model, HttpSession session) {
        User owner = currentOwner(session);
        if (owner == null) return "redirect:/login?redirect=/owner/booking-summary";

        List<Booking> bookings = bookingService.getAllBookings();
        Map<String, Long> byTheatre = new LinkedHashMap<>();
        for (Booking booking : bookings) {
            String theatre = (booking.getTheatre() == null || booking.getTheatre().isBlank())
                    ? "Unassigned" : booking.getTheatre();
            byTheatre.merge(theatre, 1L, Long::sum);
        }

        model.addAttribute("owner", owner);
        model.addAttribute("totalBookings", bookings.size());
        model.addAttribute("paidCount", bookings.stream().filter(b -> "PAID".equalsIgnoreCase(b.getStatus())).count());
        model.addAttribute("lockedCount", bookings.stream().filter(b -> "LOCKED".equalsIgnoreCase(b.getStatus())).count());
        model.addAttribute("cancelledCount", bookings.stream().filter(b -> "CANCELLED".equalsIgnoreCase(b.getStatus())).count());
        model.addAttribute("refundedCount", bookings.stream().filter(b -> "REFUNDED".equalsIgnoreCase(b.getStatus())).count());
        model.addAttribute("byTheatre", byTheatre);
        return "owner/booking-summary";
    }

    private User currentOwner(HttpSession session) {
        if (session == null) return null;
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null || !"OWNER".equalsIgnoreCase(user.getRole()) || !user.isVerified()) return null;
        return user;
    }

    private String validateTheatre(Theatre theatre, Long editingId) {
        if (theatre == null) return "Theatre details are required.";

        String name = clean(theatre.getName());
        String location = clean(theatre.getLocation());
        String city = clean(theatre.getCity());
        String address = clean(theatre.getAddress());

        if (name == null || name.length() < ValidationConfig.THEATRE_NAME_MIN_LENGTH || name.length() > 80)
            return "Theatre name must be between 2 and 80 characters.";
        if (!name.matches("^[\\p{L}\\p{N}][\\p{L}\\p{N} .&'()\\-]{1,79}$"))
            return "Theatre name contains unsupported characters.";

        if (location == null || location.length() < 2 || location.length() > 80)
            return "Location must be between 2 and 80 characters.";
        if (!location.matches("^[\\p{L}\\p{N}][\\p{L}\\p{N} .,'()\\-]{1,79}$"))
            return "Location contains unsupported characters.";

        if (city == null || city.length() < 2 || city.length() > 50)
            return "City must be between 2 and 50 characters.";
        if (!city.matches("^[\\p{L}][\\p{L} .\\-']{1,49}$"))
            return "Please enter a valid city name.";

        if (address == null || address.length() < 5 || address.length() > 180)
            return "Address must be between 5 and 180 characters.";

        int seats = theatre.getTotalSeats();
        int screens = theatre.getScreenCount();
        if (screens < ValidationConfig.THEATRE_MIN_SCREENS || screens > ValidationConfig.THEATRE_MAX_SCREENS)
            return "Screen count must be between 1 and 20.";
        if (seats < ValidationConfig.THEATRE_MIN_CAPACITY || seats > ValidationConfig.THEATRE_MAX_CAPACITY)
            return "Total seats must be between 20 and 1000.";
        if (seats < screens * ValidationConfig.THEATRE_MIN_SEATS_PER_SCREEN)
            return "Total seats must provide at least 10 seats per screen.";

        // Prevent accidental duplicate cinema records in the same city.
        boolean duplicate = theatreService.getAllTheatres().stream().anyMatch(existing ->
                existing.getId() != null &&
                !existing.getId().equals(editingId) &&
                existing.getName() != null &&
                existing.getCity() != null &&
                existing.getName().trim().equalsIgnoreCase(name) &&
                existing.getCity().trim().equalsIgnoreCase(city));
        if (duplicate)
            return "A theatre with this name already exists in the selected city.";

        theatre.setName(name);
        theatre.setLocation(location);
        theatre.setCity(city);
        theatre.setAddress(address);
        theatre.setTotalSeats(seats);
        theatre.setScreenCount(screens);
        return null;
    }

    private String clean(String value) {
        if (value == null) return null;
        String cleaned = value.trim().replaceAll("\\s{2,}", " ");
        return cleaned.isBlank() ? null : cleaned;
    }

    private double totalRevenue(List<Payment> payments) {
        return payments.stream()
                .filter(p -> "SUCCESS".equalsIgnoreCase(p.getStatus()))
                .mapToDouble(Payment::getAmount)
                .sum();
    }

    private List<MovieRevenue> topMoviesByRevenue(List<Booking> bookings, int limit) {
        Map<String, MovieRevenue> grouped = new LinkedHashMap<>();
        for (Booking booking : bookings) {
            String title = (booking.getMovieTitle() == null || booking.getMovieTitle().isBlank())
                    ? "Unknown Movie" : booking.getMovieTitle();
            grouped.computeIfAbsent(title, MovieRevenue::new).addBooking(booking.getPrice());
        }
        List<MovieRevenue> result = new ArrayList<>(grouped.values());
        result.sort(Comparator.comparingDouble(MovieRevenue::getRevenue).reversed());
        return result.size() > limit ? result.subList(0, limit) : result;
    }

    public static class MovieRevenue {
        private final String title;
        private long bookings;
        private double revenue;
        public MovieRevenue(String title) { this.title = title; }
        public void addBooking(double price) { bookings++; revenue += price; }
        public String getTitle() { return title; }
        public long getBookings() { return bookings; }
        public double getRevenue() { return revenue; }
    }
}
