package com.cinebook.cinebookingsystem.repository;

import com.cinebook.cinebookingsystem.model.Booking;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class BookingRepository {

    private final List<Booking> bookings = new ArrayList<>();

    public BookingRepository() {
        initDefaultBookings();
    }

    private void initDefaultBookings() {
        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        // Sample Preloaded Confirmed Booking 1
        Booking b1 = new Booking();
        b1.setId(1L);
        b1.setBookingReference("BK-2026-DEMO01");
        b1.setMovieId(1L);
        b1.setMovieTitle("The Last Journey");
        b1.setCustomerName("Demo Customer");
        b1.setUserEmail("customer@moviebook.com");
        b1.setTelephone("0771234567");
        b1.setTheatre("Liberty Cinema Hall");
        b1.setCity("Colombo");
        b1.setDate(today);
        b1.setShowTime("10:30 AM");
        b1.setSeatNumber("B2, B3");
        b1.setSeatCount(2);
        b1.setSubtotal(2000.00);
        b1.setConvenienceFee(100.00);
        b1.setTax(105.00);
        b1.setPrice(2205.00);
        b1.setStatus("PAID");
        b1.setPaymentMethod("CARD");
        bookings.add(b1);

        // Sample Preloaded Confirmed Booking 2 (VIP seat)
        Booking b2 = new Booking();
        b2.setId(2L);
        b2.setBookingReference("BK-2026-DEMO02");
        b2.setMovieId(1L);
        b2.setMovieTitle("The Last Journey");
        b2.setCustomerName("VIP Guest");
        b2.setUserEmail("vip@moviebook.com");
        b2.setTelephone("0779998888");
        b2.setTheatre("Liberty Cinema Hall");
        b2.setCity("Colombo");
        b2.setDate(today);
        b2.setShowTime("10:30 AM");
        b2.setSeatNumber("D1");
        b2.setSeatCount(1);
        b2.setSubtotal(1500.00);
        b2.setConvenienceFee(50.00);
        b2.setTax(77.50);
        b2.setPrice(1627.50);
        b2.setStatus("PAID");
        b2.setPaymentMethod("ONLINE");
        bookings.add(b2);
    }

    public List<Booking> findAll() {
        releaseExpiredSeats();
        return new ArrayList<>(bookings);
    }

    public List<Booking> findByUserEmail(String email) {
        releaseExpiredSeats();
        if (email == null || email.trim().isEmpty()) return new ArrayList<>();
        String clean = email.trim().toLowerCase();
        return bookings.stream()
                .filter(b -> b.getUserEmail() != null && b.getUserEmail().trim().equalsIgnoreCase(clean))
                .collect(Collectors.toList());
    }

    public synchronized void save(Booking booking) {
        if (booking.getId() == null) {
            long maxId = bookings.stream().mapToLong(b -> b.getId() != null ? b.getId() : 0L).max().orElse(0L);
            booking.setId(maxId + 1);
        } else {
            for (int i = 0; i < bookings.size(); i++) {
                if (bookings.get(i).getId().equals(booking.getId())) {
                    bookings.set(i, booking);
                    return;
                }
            }
        }
        bookings.add(booking);
    }

    public Booking findById(Long id) {
        if (id == null) return null;
        releaseExpiredSeats();
        for (Booking booking : bookings) {
            if (booking.getId() != null && booking.getId().equals(id)) {
                return booking;
            }
        }
        return null;
    }

    public Booking findByReference(String ref) {
        if (ref == null) return null;
        releaseExpiredSeats();
        for (Booking booking : bookings) {
            if (booking.getBookingReference() != null && booking.getBookingReference().equalsIgnoreCase(ref.trim())) {
                return booking;
            }
        }
        return null;
    }

    // ==========================================
    // CHECK IF ANY OF THE SEATS ARE ALREADY BOOKED
    // ==========================================
    public boolean isAnySeatBooked(String seatCsv, Long movieId, String theatre, String date, String showTime) {
        releaseExpiredSeats();
        if (seatCsv == null || seatCsv.trim().isEmpty()) return false;

        List<String> requestedSeats = Arrays.stream(seatCsv.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());

        List<String> currentlyBooked = getBookedSeatsForShow(movieId, theatre, date, showTime);
        for (String seat : requestedSeats) {
            if (currentlyBooked.contains(seat)) {
                return true;
            }
        }
        return false;
    }

    // Backwards-compatible single seat check
    public boolean isSeatBooked(String seatNumber, Long movieId, String theatre, String date, String showTime) {
        return isAnySeatBooked(seatNumber, movieId, theatre, date, showTime);
    }

    // ==========================================
    // GET ALL ACTIVE BOOKED SEATS FOR A SPECIFIC SHOW
    // ==========================================
    public List<String> getBookedSeatsForShow(Long movieId, String theatre, String date, String showTime) {
        releaseExpiredSeats();
        List<String> bookedList = new ArrayList<>();
        if (movieId == null || theatre == null || date == null || showTime == null) {
            return bookedList;
        }

        for (Booking b : bookings) {
            boolean active = "LOCKED".equalsIgnoreCase(b.getStatus()) || "PAID".equalsIgnoreCase(b.getStatus()) || "CONFIRMED".equalsIgnoreCase(b.getStatus());
            if (active &&
                    b.getMovieId() != null && b.getMovieId().equals(movieId) &&
                    b.getTheatre() != null && b.getTheatre().equalsIgnoreCase(theatre.trim()) &&
                    b.getDate() != null && b.getDate().equals(date.trim()) &&
                    b.getShowTime() != null && b.getShowTime().equalsIgnoreCase(showTime.trim())) {

                if (b.getSeatNumber() != null) {
                    for (String s : b.getSeatNumber().split(",")) {
                        String trimmed = s.trim();
                        if (!trimmed.isEmpty() && !bookedList.contains(trimmed)) {
                            bookedList.add(trimmed);
                        }
                    }
                }
            }
        }
        return bookedList;
    }

    // ==========================================
    // AUTO RELEASE EXPIRED SEAT LOCKS
    // ==========================================
    public synchronized void releaseExpiredSeats() {
        long now = System.currentTimeMillis();
        for (Booking booking : bookings) {
            if ("LOCKED".equalsIgnoreCase(booking.getStatus()) && booking.getLockExpiryTime() > 0 && booking.getLockExpiryTime() <= now) {
                booking.setStatus("EXPIRED");
                booking.setLockExpiryTime(0);
            }
        }
    }

    // ==========================================
    // CANCEL BOOKING (DEMO CANCELLATION)
    // ==========================================
    public synchronized boolean cancelBooking(Long bookingId) {
        for (Booking booking : bookings) {
            if (booking.getId() != null && booking.getId().equals(bookingId)) {
                booking.setStatus("CANCELLED");
                booking.setLockExpiryTime(0);
                return true;
            }
        }
        return false;
    }

    // ==========================================
    // RELEASE SEAT AFTER REFUND
    // ==========================================
    public synchronized boolean releaseSeat(Long bookingId) {
        for (Booking booking : bookings) {
            if (booking.getId() != null && booking.getId().equals(bookingId)) {
                booking.setStatus("REFUNDED");
                booking.setLockExpiryTime(0);
                return true;
            }
        }
        return false;
    }
}