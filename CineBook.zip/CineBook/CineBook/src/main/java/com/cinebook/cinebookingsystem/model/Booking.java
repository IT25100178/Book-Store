package com.cinebook.cinebookingsystem.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class Booking {
    private Long id;
    private String bookingReference;
    private Long movieId;
    private String movieTitle;
    private String customerName;
    private String userEmail;
    private String telephone;
    private String theatre;
    private String city;
    private String date;
    private String showTime;
    private String seatNumber; // Comma-separated if multiple e.g. "A1, A2"
    private int seatCount = 1;
    private double subtotal;
    private double convenienceFee;
    private double tax;
    private double discount;
    private double price; // Final total amount
    private String status = "LOCKED";
    private long lockExpiryTime;
    private String paymentMethod;
    private String bookingCreatedAt;

    public Booking() {
        this.bookingReference = "BK-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        this.bookingCreatedAt = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBookingReference() {
        if (bookingReference == null || bookingReference.isEmpty()) {
            bookingReference = "BK-" + (id != null ? id : "") + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        }
        return bookingReference;
    }

    public void setBookingReference(String bookingReference) {
        this.bookingReference = bookingReference;
    }

    public Long getMovieId() {
        return movieId;
    }

    public void setMovieId(Long movieId) {
        this.movieId = movieId;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getTheatre() {
        return theatre;
    }

    public void setTheatre(String theatre) {
        this.theatre = theatre;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getShowTime() {
        return showTime;
    }

    public void setShowTime(String showTime) {
        this.showTime = showTime;
    }

    public String getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
        if (seatNumber != null && !seatNumber.trim().isEmpty()) {
            this.seatCount = seatNumber.split(",").length;
        }
    }

    public int getSeatCount() {
        return seatCount > 0 ? seatCount : (seatNumber != null ? seatNumber.split(",").length : 1);
    }

    public void setSeatCount(int seatCount) {
        this.seatCount = seatCount;
    }

    public double getSubtotal() {
        return subtotal > 0 ? subtotal : price;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getConvenienceFee() {
        return convenienceFee;
    }

    public void setConvenienceFee(double convenienceFee) {
        this.convenienceFee = convenienceFee;
    }

    public double getTax() {
        return tax;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getLockExpiryTime() {
        return lockExpiryTime;
    }

    public void setLockExpiryTime(long lockExpiryTime) {
        this.lockExpiryTime = lockExpiryTime;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getBookingCreatedAt() {
        return bookingCreatedAt;
    }

    public void setBookingCreatedAt(String bookingCreatedAt) {
        this.bookingCreatedAt = bookingCreatedAt;
    }
}