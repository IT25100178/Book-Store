package com.cinebook.cinebookingsystem.repository;

import com.cinebook.cinebookingsystem.model.Payment;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class PaymentRepository {

    private final List<Payment> payments = new ArrayList<>();

    public List<Payment> findAll() {
        return payments;
    }

    public void save(Payment payment) {

        payment.setId(
                (long) (payments.size() + 1)
        );

        payments.add(payment);
    }

    public Payment findByBookingId(Long bookingId) {

        for (Payment payment : payments) {

            if (payment.getBookingId() != null
                    && payment.getBookingId().equals(bookingId)) {

                return payment;
            }
        }

        return null;
    }
}