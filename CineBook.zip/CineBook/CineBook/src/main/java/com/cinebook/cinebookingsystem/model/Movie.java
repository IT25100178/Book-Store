package com.cinebook.cinebookingsystem.model;

public class Movie {
    private Long id;
    private String title;
    private String genre;
    private String description;
    private String posterUrl;
    private double rating;
    private String language;
    private String duration;
    private String releaseDate;
    private String status; // "NOW_SHOWING", "COMING_SOON"
    private String director;
    private String cast;

    public Movie() {}

    public Movie(Long id, String title, String genre, String description, String posterUrl,
                 double rating, String language, String duration, String releaseDate, String status) {
        this.id = id;
        this.title = title;
        this.genre = genre;
        this.description = description;
        this.posterUrl = posterUrl;
        this.rating = rating;
        this.language = language;
        this.duration = duration;
        this.releaseDate = releaseDate;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPosterUrl() {
        return posterUrl;
    }

    public void setPosterUrl(String posterUrl) {
        this.posterUrl = posterUrl;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getStatus() {
        return status != null ? status : "NOW_SHOWING";
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getCast() {
        return cast;
    }

    public void setCast(String cast) {
        this.cast = cast;
    }
}