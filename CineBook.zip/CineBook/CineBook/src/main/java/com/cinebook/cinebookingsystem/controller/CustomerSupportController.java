package com.cinebook.cinebookingsystem.controller;

import com.cinebook.cinebookingsystem.model.SupportTicket;
import com.cinebook.cinebookingsystem.service.CustomerSupportService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CustomerSupportController {

    private final CustomerSupportService supportService;

    public CustomerSupportController(CustomerSupportService supportService) {
        this.supportService = supportService;
    }

    @GetMapping("/support")
    public String dashboard(Model model) {
        var tickets = supportService.getAllTickets();

        model.addAttribute("tickets", tickets);
        model.addAttribute("ticketCount", tickets.size());
        model.addAttribute("openCount",
                tickets.stream().filter(ticket -> "OPEN".equals(ticket.getStatus())).count());
        model.addAttribute("resolvedCount",
                tickets.stream().filter(ticket -> "RESOLVED".equals(ticket.getStatus())).count());

        return "support/dashboard";
    }

    @GetMapping("/support/tickets")
    public String tickets(Model model) {
        model.addAttribute("tickets", supportService.getAllTickets());
        return "support/tickets";
    }

    @GetMapping("/support/tickets/add")
    public String addTicketPage(Model model) {
        model.addAttribute("ticket", new SupportTicket());
        return "support/add-ticket";
    }

    @PostMapping("/support/tickets/add")
    public String addTicket(@ModelAttribute SupportTicket ticket) {
        supportService.createTicket(ticket);
        return "redirect:/support/tickets";
    }

    @GetMapping("/support/tickets/view")
    public String viewTicket(@RequestParam Long id, Model model) {
        SupportTicket ticket = supportService.getTicketById(id);

        if (ticket == null) {
            return "redirect:/support/tickets";
        }

        model.addAttribute("ticket", ticket);
        return "support/ticket-details";
    }

    @PostMapping("/support/tickets/respond")
    public String respondToTicket(@RequestParam Long id,
                                  @RequestParam String response) {
        supportService.respondToTicket(id, response);
        return "redirect:/support/tickets/view?id=" + id;
    }

    @PostMapping("/support/tickets/delete")
    public String deleteTicket(@RequestParam Long id) {
        supportService.deleteTicket(id);
        return "redirect:/support/tickets";
    }

    @GetMapping("/contact-support")
    public String contactSupport(Model model) {
        model.addAttribute("ticket", new SupportTicket());
        return "contact-support";
    }

    @PostMapping("/contact-support")
    public String submitCustomerTicket(@ModelAttribute SupportTicket ticket) {
        supportService.createTicket(ticket);
        return "redirect:/contact-support?success=true";
    }

    @GetMapping("/my-support-tickets")
    public String mySupportTickets(Model model) {
        model.addAttribute("tickets", supportService.getAllTickets());
        return "my-support-tickets";
    }
}
