package com.cinebook.cinebookingsystem.service;

import com.cinebook.cinebookingsystem.model.SupportTicket;
import com.cinebook.cinebookingsystem.repository.SupportTicketRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerSupportService {

    private final SupportTicketRepository supportTicketRepository;

    public CustomerSupportService(SupportTicketRepository supportTicketRepository) {
        this.supportTicketRepository = supportTicketRepository;
    }

    public SupportTicket createTicket(SupportTicket ticket) {
        if (ticket == null) {
            return null;
        }

        normalizeTicket(ticket);

        if (ticket.getStatus() == null || ticket.getStatus().isBlank()) {
            ticket.setStatus("OPEN");
        }

        if (ticket.getResponse() == null) {
            ticket.setResponse("");
        }

        return supportTicketRepository.save(ticket);
    }

    public List<SupportTicket> getTicketsByUserId(Long userId) {
        if (userId == null) {
            return new ArrayList<>();
        }
        return supportTicketRepository.findByUserId(userId);
    }

    public List<SupportTicket> getAllTickets() {
        return supportTicketRepository.findAll();
    }

    public SupportTicket getTicketById(Long ticketId) {
        if (ticketId == null) {
            return null;
        }
        return supportTicketRepository.findById(ticketId).orElse(null);
    }

    public boolean updateTicketStatus(Long ticketId, String newStatus) {
        if (ticketId == null || newStatus == null || newStatus.isBlank()) {
            return false;
        }

        Optional<SupportTicket> ticketOptional =
                supportTicketRepository.findById(ticketId);

        if (ticketOptional.isEmpty()) {
            return false;
        }

        SupportTicket ticket = ticketOptional.get();
        ticket.setStatus(newStatus.trim().toUpperCase());
        supportTicketRepository.save(ticket);
        return true;
    }

    public boolean respondToTicket(Long ticketId, String response) {
        if (ticketId == null || response == null || response.isBlank()) {
            return false;
        }

        Optional<SupportTicket> ticketOptional =
                supportTicketRepository.findById(ticketId);

        if (ticketOptional.isEmpty()) {
            return false;
        }

        SupportTicket ticket = ticketOptional.get();
        ticket.setResponse(response.trim());
        ticket.setStatus("RESOLVED");
        supportTicketRepository.save(ticket);
        return true;
    }

    public boolean deleteTicket(Long ticketId) {
        return supportTicketRepository.deleteById(ticketId);
    }

    private void normalizeTicket(SupportTicket ticket) {
        if (ticket.getCustomerName() != null) {
            ticket.setCustomerName(ticket.getCustomerName().trim());
        }
        if (ticket.getEmail() != null) {
            ticket.setEmail(ticket.getEmail().trim());
        }
        if (ticket.getSubject() != null) {
            ticket.setSubject(ticket.getSubject().trim());
        }
        if (ticket.getMessage() != null) {
            ticket.setMessage(ticket.getMessage().trim());
        }
    }
}
