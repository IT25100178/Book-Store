package com.cinebook.cinebookingsystem.service;

import com.cinebook.cinebookingsystem.model.User;
import com.cinebook.cinebookingsystem.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public boolean registerUser(User user) {
        if (user == null) return false;
        if (user.getRole() == null || user.getRole().isBlank()) user.setRole("CUSTOMER");
        user.setStatus("ACTIVE");
        user.setVerified(!"OWNER".equalsIgnoreCase(user.getRole()));
        userRepository.save(user);
        return true;
    }

    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public User findUserByEmail(String email) {
        return userRepository.findByEmail(email).orElse(null);
    }

    public User findUserByUsername(String username) {
        return userRepository.findByUsername(username).orElse(null);
    }

    public User loginUser(String identifier, String password) {
        if (identifier == null || password == null) return null;
        User user = findUserByEmail(identifier);
        if (user == null) user = findUserByUsername(identifier);
        if (user == null || user.getPassword() == null || !user.getPassword().equals(password)) return null;
        return user;
    }

    public boolean updateUser(User user) {
        if (user == null || user.getId() == null) return false;
        Optional<User> existing = userRepository.findById(user.getId());
        if (existing.isEmpty()) return false;
        User old = existing.get();
        user.setPassword(old.getPassword());
        user.setRole(old.getRole());
        user.setStatus(old.getStatus());
        user.setVerified(old.isVerified());
        userRepository.save(user);
        return true;
    }

    public boolean resetPassword(String email, String newPassword) {
        Optional<User> user = userRepository.findByEmail(email);
        if (user.isEmpty()) return false;
        user.get().setPassword(newPassword);
        userRepository.save(user.get());
        return true;
    }

    public List<User> getAllUsers() { return userRepository.findAll(); }

    public boolean verifyOwner(Long ownerId) {
        Optional<User> user = userRepository.findById(ownerId);
        if (user.isEmpty() || !"OWNER".equalsIgnoreCase(user.get().getRole())) return false;
        user.get().setVerified(true);
        userRepository.save(user.get());
        return true;
    }
}
