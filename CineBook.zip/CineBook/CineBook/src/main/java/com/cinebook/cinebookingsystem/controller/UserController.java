package com.cinebook.cinebookingsystem.controller;

import com.cinebook.cinebookingsystem.config.ValidationConfig;
import com.cinebook.cinebookingsystem.model.User;
import com.cinebook.cinebookingsystem.service.EmailService;
import com.cinebook.cinebookingsystem.service.UserService;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UserController {

    private final UserService userService;
    private final EmailService emailService;

    public UserController(UserService userService, EmailService emailService) {
        this.userService = userService;
        this.emailService = emailService;
    }

    // ==========================================
    // SIGN UP
    // ==========================================
    @GetMapping("/signup")
    public String signupPage(Model model) {
        model.addAttribute("user", new User());
        return "signup";
    }

    @PostMapping("/signup")
    public String registerUser(
            @ModelAttribute User user,
            @RequestParam(required = false) String confirmPassword,
            Model model) {

        if (confirmPassword != null) {
            user.setConfirmPassword(confirmPassword.trim());
        }

        // Trim fields
        String name = user.getName() != null ? user.getName().trim() : "";
        String email = user.getEmail() != null ? user.getEmail().trim().toLowerCase() : "";
        String username = user.getUsername() != null ? user.getUsername().trim().toLowerCase() : "";
        String telephone = user.getTelephone() != null ? user.getTelephone().trim() : "";
        String password = user.getPassword() != null ? user.getPassword().trim() : "";
        String confirm = user.getConfirmPassword() != null ? user.getConfirmPassword().trim() : "";

        // Validations
        if (name.length() < ValidationConfig.NAME_MIN_LENGTH) {
            model.addAttribute("error", "Full name must be at least " + ValidationConfig.NAME_MIN_LENGTH + " characters.");
            model.addAttribute("user", user);
            return "signup";
        }

        if (!ValidationConfig.isValidEmail(email)) {
            model.addAttribute("error", "Please provide a valid email address.");
            model.addAttribute("user", user);
            return "signup";
        }

        if (userService.findUserByEmail(email) != null) {
            model.addAttribute("error", "An account with this email already exists.");
            model.addAttribute("user", user);
            return "signup";
        }

        if (username.length() < ValidationConfig.USERNAME_MIN_LENGTH) {
            model.addAttribute("error", "Username must be at least " + ValidationConfig.USERNAME_MIN_LENGTH + " characters.");
            model.addAttribute("user", user);
            return "signup";
        }

        if (userService.findUserByUsername(username) != null) {
            model.addAttribute("error", "This username is already taken. Please choose another.");
            model.addAttribute("user", user);
            return "signup";
        }

        if (!ValidationConfig.isValidMobile(telephone)) {
            model.addAttribute("error", "Please provide a valid 10-digit mobile number (e.g. 0771234567).");
            model.addAttribute("user", user);
            return "signup";
        }

        if (!ValidationConfig.isValidPassword(password)) {
            model.addAttribute("error", "Password must be at least 8 characters long and contain both letters and numbers.");
            model.addAttribute("user", user);
            return "signup";
        }

        if (!password.equals(confirm)) {
            model.addAttribute("error", "Passwords do not match. Please re-enter.");
            model.addAttribute("user", user);
            return "signup";
        }

        user.setName(name);
        user.setEmail(email);
        user.setUsername(username);
        user.setTelephone(telephone);
        user.setPassword(password);

        boolean registered = userService.registerUser(user);
        if (!registered) {
            model.addAttribute("error", "Registration could not be completed. Please check your inputs.");
            model.addAttribute("user", user);
            return "signup";
        }

        // Send simulated welcome/verification note to log
        emailService.sendVerificationCode(email, "123456");

        return "redirect:/login?signup=success";
    }

    // ==========================================
    // LOGIN
    // ==========================================
    @GetMapping("/login")
    public String loginPage(
            @RequestParam(required = false) String redirect,
            @RequestParam(required = false) String error,
            @RequestParam(required = false) String signup,
            @RequestParam(required = false) String reset,
            Model model) {

        model.addAttribute("user", new User());
        model.addAttribute("redirect", redirect);
        if (error != null) model.addAttribute("error", error);
        if (signup != null) model.addAttribute("success", "Account created successfully! Please log in with your credentials.");
        if (reset != null) model.addAttribute("success", "Password reset successfully! Please log in with your new password.");

        return "login";
    }

    @PostMapping("/login")
    public String loginUser(
            @RequestParam("email") String identifier,
            @RequestParam("password") String password,
            @RequestParam(value = "rememberMe", required = false) String rememberMe,
            @RequestParam(value = "redirect", required = false) String redirect,
            Model model,
            HttpSession session,
            HttpServletResponse response) {

        if (identifier == null || identifier.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            model.addAttribute("error", "Please enter both your email/username and password.");
            model.addAttribute("user", new User());
            model.addAttribute("redirect", redirect);
            return "login";
        }

        User loggedInUser = userService.loginUser(identifier.trim(), password.trim());

        if (loggedInUser == null) {
            model.addAttribute("error", "Invalid credentials. Please verify your email/username and password.");
            model.addAttribute("user", new User());
            model.addAttribute("redirect", redirect);
            return "login";
        }

        if ("BLOCKED".equalsIgnoreCase(loggedInUser.getStatus())) {
            model.addAttribute("error", "Your account is currently blocked. Please contact support.");
            model.addAttribute("user", new User());
            model.addAttribute("redirect", redirect);
            return "login";
        }

        // Store user in session
        session.setAttribute("loggedInUser", loggedInUser);
        session.setAttribute("userName", loggedInUser.getName());
        session.setAttribute("userEmail", loggedInUser.getEmail());
        session.setAttribute("userRole", loggedInUser.getRole());

        // Redirect back to intended target page if provided
        if (redirect != null && !redirect.trim().isEmpty() && redirect.startsWith("/")) {
            return "redirect:" + redirect;
        }

        // Admin redirect
        if ("ADMIN".equalsIgnoreCase(loggedInUser.getRole())) {
            return "redirect:/admin";
        }

        return "redirect:/?login=success";
    }

    // ==========================================
    // LOGOUT
    // ==========================================
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        if (session != null) {
            session.invalidate();
        }
        return "redirect:/?logout=success";
    }

    // ==========================================
    // FORGOT PASSWORD (DEMO SIMULATION)
    // ==========================================
    @GetMapping("/forgot-password")
    public String forgotPasswordPage(Model model) {
        model.addAttribute("user", new User());
        return "forgot-password";
    }

    @PostMapping("/forgot-password")
    public String resetPassword(
            @RequestParam("email") String email,
            @RequestParam("password") String newPassword,
            @RequestParam("confirmPassword") String confirmPassword,
            Model model) {

        if (email == null || email.trim().isEmpty()) {
            model.addAttribute("error", "Please enter your registered email address.");
            return "forgot-password";
        }

        if (newPassword == null || !ValidationConfig.isValidPassword(newPassword.trim())) {
            model.addAttribute("error", "New password must be at least 8 characters and contain letters and numbers.");
            return "forgot-password";
        }

        if (!newPassword.equals(confirmPassword)) {
            model.addAttribute("error", "Passwords do not match. Please verify.");
            return "forgot-password";
        }

        boolean reset = userService.resetPassword(email.trim(), newPassword.trim());
        if (!reset) {
            model.addAttribute("error", "No registered account found with email: " + email.trim());
            return "forgot-password";
        }

        return "redirect:/login?reset=success";
    }

    // ==========================================
    // PROFILE
    // ==========================================
    @GetMapping("/profile")
    public String profilePage(HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            return "redirect:/login?redirect=/profile";
        }
        model.addAttribute("user", loggedInUser);
        return "profile";
    }

    @PostMapping("/profile")
    public String updateProfile(
            @ModelAttribute User user,
            HttpSession session,
            Model model) {

        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            return "redirect:/login?redirect=/profile";
        }

        // Validate updated fields
        if (user.getName() == null || user.getName().trim().length() < ValidationConfig.NAME_MIN_LENGTH) {
            model.addAttribute("error", "Full name must be at least " + ValidationConfig.NAME_MIN_LENGTH + " characters.");
            model.addAttribute("user", loggedInUser);
            return "profile";
        }

        if (!ValidationConfig.isValidMobile(user.getTelephone())) {
            model.addAttribute("error", "Please provide a valid 10-digit mobile number.");
            model.addAttribute("user", loggedInUser);
            return "profile";
        }

        // Keep ID, username, password, and role unchanged
        user.setId(loggedInUser.getId());
        user.setUsername(loggedInUser.getUsername());
        user.setPassword(loggedInUser.getPassword());
        user.setRole(loggedInUser.getRole());
        user.setStatus(loggedInUser.getStatus());

        boolean updated = userService.updateUser(user);
        if (!updated) {
            model.addAttribute("error", "Unable to update profile. Please try again.");
            model.addAttribute("user", loggedInUser);
            return "profile";
        }

        // Update session
        session.setAttribute("loggedInUser", user);
        session.setAttribute("userName", user.getName());
        session.setAttribute("userEmail", user.getEmail());

        return "redirect:/profile?success=true";
    }
}