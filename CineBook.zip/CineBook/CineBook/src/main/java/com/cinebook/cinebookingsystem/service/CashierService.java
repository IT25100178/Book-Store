package com.cinebook.cinebookingsystem.service;

import com.cinebook.cinebookingsystem.model.Booking;
import com.cinebook.cinebookingsystem.model.Payment;
import com.cinebook.cinebookingsystem.repository.BookingRepository;
import com.cinebook.cinebookingsystem.repository.PaymentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CashierService {

    private final PaymentRepository paymentRepository;
    private final BookingService bookingService;
    private final BookingRepository bookingRepository;

    public CashierService(
            PaymentRepository paymentRepository,
            BookingService bookingService,
            BookingRepository bookingRepository) {

        this.paymentRepository = paymentRepository;
        this.bookingService = bookingService;
        this.bookingRepository = bookingRepository;
    }

    // Process Payment
    public Payment processPayment(
            Long bookingId,
            double amount,
            String paymentMethod) {

        Booking selectedBooking = null;

        // Find booking
        for (Booking booking :
                bookingService.getAllBookings()) {

            if (booking.getId() != null
                    && booking.getId().equals(bookingId)) {

                selectedBooking = booking;
                break;
            }
        }

        Payment payment = new Payment();

        payment.setBookingId(bookingId);
        payment.setPaymentMethod(paymentMethod == null ? null : paymentMethod.trim().toUpperCase());

        // Check whether booking exists
        if (selectedBooking == null) {

            payment.setAmount(amount);
            payment.setStatus("FAILED");

            paymentRepository.save(payment);

            return payment;
        }

        // Check whether booking is still locked
        if (!"LOCKED".equals(selectedBooking.getStatus())) {

            payment.setAmount(selectedBooking.getPrice());
            payment.setStatus("FAILED");

            paymentRepository.save(payment);

            return payment;
        }

        // Validate payment method and sufficient amount
        if (payment.getPaymentMethod() == null
                || !("CASH".equals(payment.getPaymentMethod())
                || "CARD".equals(payment.getPaymentMethod())
                || "ONLINE".equals(payment.getPaymentMethod()))) {
            payment.setAmount(amount);
            payment.setStatus("FAILED");
            paymentRepository.save(payment);
            return payment;
        }

        // Use the actual booking price
        payment.setAmount(selectedBooking.getPrice());

        if (amount >= selectedBooking.getPrice() && selectedBooking.getPrice() > 0) {

            payment.setStatus("SUCCESS");

            // Change booking status to PAID
            selectedBooking.setStatus("PAID");
            selectedBooking.setLockExpiryTime(0);

        } else {

            payment.setStatus("FAILED");
        }

        paymentRepository.save(payment);

        return payment;
    }

    // Get payment by Booking ID
    public Payment getPaymentByBookingId(
            Long bookingId) {

        return paymentRepository.findByBookingId(
                bookingId
        );
    }

    // Get all payments
    public List<Payment> getAllPayments() {

        return paymentRepository.findAll();
    }

    // Process Refund
    public boolean processRefund(
            Long bookingId) {

        Payment payment =
                paymentRepository.findByBookingId(
                        bookingId
                );

        if (payment != null
                && "SUCCESS".equals(
                payment.getStatus())) {

            // Change payment status
            payment.setStatus("REFUNDED");

            // Release the booking seat
            bookingRepository.releaseSeat(
                    bookingId
            );

            return true;
        }

        return false;
    }
}