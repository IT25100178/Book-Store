package com.cinebook.cinebookingsystem.model;

public class Showtime {

    private Long id;
    private Long movieId;
    private String movieTitle;
    private String theatre;
    private String city;
    private String hallName;
    private String date;
    private String showTime;
    private int totalSeats;
    private int availableSeats;
    private double standardPrice;
    private double premiumPrice;

    public Showtime() {}

    public Showtime(Long id, Long movieId, String movieTitle, String theatre, String city,
                    String date, String showTime, int totalSeats, int availableSeats) {
        this.id = id;
        this.movieId = movieId;
        this.movieTitle = movieTitle;
        this.theatre = theatre;
        this.city = city;
        this.date = date;
        this.showTime = showTime;
        this.totalSeats = totalSeats;
        this.availableSeats = availableSeats;
        this.standardPrice = 1000.00;
        this.premiumPrice = 1500.00;
        this.hallName = "Screen 1";
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMovieId() {
        return movieId;
    }

    public void setMovieId(Long movieId) {
        this.movieId = movieId;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    public String getTheatre() {
        return theatre;
    }

    public void setTheatre(String theatre) {
        this.theatre = theatre;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getHallName() {
        return hallName != null ? hallName : "Screen 1";
    }

    public void setHallName(String hallName) {
        this.hallName = hallName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getShowTime() {
        return showTime;
    }

    public void setShowTime(String showTime) {
        this.showTime = showTime;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public void setTotalSeats(int totalSeats) {
        this.totalSeats = totalSeats;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    public double getStandardPrice() {
        return standardPrice > 0 ? standardPrice : 1000.00;
    }

    public void setStandardPrice(double standardPrice) {
        this.standardPrice = standardPrice;
    }

    public double getPremiumPrice() {
        return premiumPrice > 0 ? premiumPrice : 1500.00;
    }

    public void setPremiumPrice(double premiumPrice) {
        this.premiumPrice = premiumPrice;
    }
}