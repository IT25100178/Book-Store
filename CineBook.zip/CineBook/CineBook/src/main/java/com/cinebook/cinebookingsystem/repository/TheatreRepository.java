package com.cinebook.cinebookingsystem.repository;

import com.cinebook.cinebookingsystem.model.Theatre;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class TheatreRepository {

    private final List<Theatre> theatres = new ArrayList<>();

    // ==========================================
    // PRELOADED DEMO THEATRES (4 THEATRES ACROSS 4 CITIES)
    // ==========================================
    public TheatreRepository() {
        initDefaultTheatres();
    }

    private void initDefaultTheatres() {
        Theatre t1 = new Theatre(1L, "Liberty Cinema Hall", "Colombo 07", "Colombo", 180);
        t1.setScreenCount(2);
        t1.setAddress("235 Dharmapala Mawatha, Colombo 07");
        theatres.add(t1);

        Theatre t2 = new Theatre(2L, "KCC Cineplex", "Kandy City Centre", "Kandy", 150);
        t2.setScreenCount(2);
        t2.setAddress("Kandy City Centre, Dalada Veediya, Kandy");
        theatres.add(t2);

        Theatre t3 = new Theatre(3L, "SLIIT Cinema Hall", "Jaffna Central", "Jaffna", 160);
        t3.setScreenCount(1);
        t3.setAddress("Main Street, Jaffna");
        theatres.add(t3);

        Theatre t4 = new Theatre(4L, "Galle Marine Multiplex", "Galle Fort", "Galle", 140);
        t4.setScreenCount(2);
        t4.setAddress("Marine Walk Road, Galle Fort");
        theatres.add(t4);
    }

    // ==========================================
    // FIND ALL THEATRES
    // ==========================================
    public List<Theatre> findAll() {
        return new ArrayList<>(theatres);
    }

    // ==========================================
    // SAVE THEATRE
    // ==========================================
    public synchronized void save(Theatre theatre) {
        if (theatre.getId() == null) {
            long maxId = theatres.stream().mapToLong(t -> t.getId() != null ? t.getId() : 0L).max().orElse(0L);
            theatre.setId(maxId + 1);
        } else {
            for (int i = 0; i < theatres.size(); i++) {
                if (theatres.get(i).getId().equals(theatre.getId())) {
                    theatres.set(i, theatre);
                    return;
                }
            }
        }
        theatres.add(theatre);
    }

    // ==========================================
    // FIND THEATRE BY ID
    // ==========================================
    public Theatre findById(Long id) {
        if (id == null) return null;
        for (Theatre theatre : theatres) {
            if (theatre.getId() != null && theatre.getId().equals(id)) {
                return theatre;
            }
        }
        return null;
    }

    // ==========================================
    // UPDATE THEATRE
    // ==========================================
    public synchronized boolean updateTheatre(Theatre updatedTheatre) {
        if (updatedTheatre == null || updatedTheatre.getId() == null) return false;
        Theatre existing = findById(updatedTheatre.getId());
        if (existing != null) {
            existing.setName(updatedTheatre.getName());
            existing.setLocation(updatedTheatre.getLocation());
            existing.setCity(updatedTheatre.getCity());
            existing.setTotalSeats(updatedTheatre.getTotalSeats());
            existing.setScreenCount(updatedTheatre.getScreenCount());
            existing.setAddress(updatedTheatre.getAddress());
            return true;
        }
        return false;
    }

    // ==========================================
    // DELETE THEATRE
    // ==========================================
    public synchronized boolean deleteById(Long id) {
        if (id == null) return false;
        return theatres.removeIf(theatre -> theatre.getId() != null && theatre.getId().equals(id));
    }
}