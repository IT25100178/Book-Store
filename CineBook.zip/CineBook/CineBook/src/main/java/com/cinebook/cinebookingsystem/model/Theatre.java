package com.cinebook.cinebookingsystem.model;

public class Theatre {

    private Long id;
    private String name;
    private String location;
    private String city;
    private int totalSeats;
    private int screenCount;
    private String address;

    public Theatre() {}

    public Theatre(Long id, String name, String location, String city, int totalSeats) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.city = city;
        this.totalSeats = totalSeats;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCity() {
        return (city != null && !city.isEmpty()) ? city : location;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public void setTotalSeats(int totalSeats) {
        this.totalSeats = totalSeats;
    }

    public int getScreenCount() {
        return screenCount > 0 ? screenCount : 1;
    }

    public void setScreenCount(int screenCount) {
        this.screenCount = screenCount;
    }

    public String getAddress() {
        return address != null ? address : location;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}