package com.cinebook.cinebookingsystem.model;

public class SupportTicket {

    private Long id;
    private Long userId;
    private String customerName;
    private String email;
    private String subject;
    private String message;
    private String status; // OPEN, IN_PROGRESS, RESOLVED, CLOSED
    private String response;

    public SupportTicket() {
    }

    public SupportTicket(Long id, Long userId, String customerName, String email,
                          String subject, String message, String status, String response) {
        this.id = id;
        this.userId = userId;
        this.customerName = customerName;
        this.email = email;
        this.subject = subject;
        this.message = message;
        this.status = status;
        this.response = response;
    }

    // Backward-compatible constructor for existing code.
    public SupportTicket(Long id, Long userId, String userEmail, String subject,
                          String message, String status) {
        this(id, userId, null, userEmail, subject, message, status, "");
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    // Keep userEmail compatibility with any older code.
    public String getUserEmail() { return email; }
    public void setUserEmail(String userEmail) { this.email = userEmail; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getResponse() { return response; }
    public void setResponse(String response) { this.response = response; }
}
