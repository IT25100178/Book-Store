package com.cinebook.cinebookingsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    @Autowired(required = false)
    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    // Default constructor if mailSender bean is not available
    public EmailService() {
        this.mailSender = null;
    }

    /**
     * Safe simulated verification code sender.
     * Logs the code to console and never fails.
     */
    public boolean sendVerificationCode(String toEmail, String code) {
        System.out.println("=================================================");
        System.out.println("[DEMO EMAIL SIMULATION] Verification Code for: " + toEmail);
        System.out.println("CODE: " + code);
        System.out.println("=================================================");

        String username = System.getenv("MAIL_USERNAME");
        String password = System.getenv("MAIL_PASSWORD");
        if (username != null && !username.isBlank() && password != null && !password.isBlank() && mailSender != null) {
            try {
                SimpleMailMessage message = new SimpleMailMessage();
                message.setTo(toEmail);
                message.setSubject("Cine Book - Email Verification Code");
                message.setText("Your Cine Book verification code is: " + code);
                mailSender.send(message);
                return true;
            } catch (Exception e) {
                System.out.println("[DEMO NOTICE] SMTP send failed; falling back safely to local simulation: " + e.getMessage());
            }
        }
        return true;
    }
}