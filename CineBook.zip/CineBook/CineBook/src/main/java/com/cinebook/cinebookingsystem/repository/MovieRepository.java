package com.cinebook.cinebookingsystem.repository;

import com.cinebook.cinebookingsystem.model.Movie;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class MovieRepository {

    private final List<Movie> movies = new ArrayList<>();

    // ==========================================
    // PRELOADED DEMO MOVIES (8 MOVIES WITH IMAGES)
    // ==========================================
    public MovieRepository() {
        initDefaultMovies();
    }

    private void initDefaultMovies() {
        movies.add(new Movie(
                1L,
                "The Last Journey",
                "Action • Adventure • Sci-Fi",
                "An exhilarating interstellar expedition embarks on a perilous voyage beyond the known frontiers to save humanity.",
                "/images/The Last Journey.jpg",
                8.7,
                "English",
                "148 mins",
                "2026-03-15",
                "NOW_SHOWING"
        ));

        movies.add(new Movie(
                2L,
                "Midnight Story",
                "Drama • Thriller • Mystery",
                "A mysterious detective unravels a web of deceptive secrets buried deep within an enigmatic high-society crime at midnight.",
                "/images/Midnight Story.jpg",
                8.4,
                "English",
                "125 mins",
                "2026-04-10",
                "NOW_SHOWING"
        ));

        movies.add(new Movie(
                3L,
                "Galaxy War",
                "Sci-Fi • Action • Space",
                "Allied planetary fleets unite in an epic galactic battle for universal sovereignty against an all-consuming cosmic armada.",
                "/images/Galaxy War.jpg",
                9.1,
                "English",
                "155 mins",
                "2026-02-28",
                "NOW_SHOWING"
        ));

        movies.add(new Movie(
                4L,
                "Love Again",
                "Romance • Comedy • Drama",
                "A heartwarming and witty journey of two people finding romance and laughter unexpectedly in the bustling heart of the city.",
                "/images/Love Again.jpg",
                8.2,
                "English",
                "118 mins",
                "2026-05-01",
                "NOW_SHOWING"
        ));

        movies.add(new Movie(
                5L,
                "Sarthar",
                "Action • Drama • Thriller",
                "A gripping espionage thriller following an estranged undercover agent racing against time to protect innocent lives.",
                "/images/sarthar.jpg",
                8.7,
                "Tamil",
                "142 mins",
                "2026-01-20",
                "NOW_SHOWING"
        ));

        movies.add(new Movie(
                6L,
                "Mandaadi",
                "Drama • Romance • Family",
                "An emotionally captivating narrative depicting resilient village traditions, heartfelt romance, and timeless courage.",
                "/images/Mandaadi.jpg",
                8.5,
                "Sinhala",
                "135 mins",
                "2026-02-14",
                "NOW_SHOWING"
        ));

        movies.add(new Movie(
                7L,
                "Immortal",
                "Action • Fantasy • Adventure",
                "An ancient immortal guardian awakens in modern times to confront an ancestral sorcerer threatening planetary equilibrium.",
                "/images/immortal.jpg",
                8.4,
                "English",
                "145 mins",
                "2026-06-18",
                "NOW_SHOWING"
        ));

        movies.add(new Movie(
                8L,
                "DC Chronicles",
                "Action • Superhero • Fantasy",
                "Legendary heroes join forces across parallel dimensions in a spectacular clash of superpowers and sacrifice.",
                "/images/DC.jpg",
                8.6,
                "English",
                "160 mins",
                "2026-07-04",
                "NOW_SHOWING"
        ));
    }

    // ==========================================
    // FIND ALL MOVIES
    // ==========================================
    public List<Movie> findAll() {
        return new ArrayList<>(movies);
    }

    // ==========================================
    // SAVE MOVIE
    // ==========================================
    public synchronized void save(Movie movie) {
        if (movie.getId() == null) {
            long maxId = movies.stream().mapToLong(m -> m.getId() != null ? m.getId() : 0L).max().orElse(0L);
            movie.setId(maxId + 1);
        } else {
            // If movie with this ID already exists, update instead of duplicating
            for (int i = 0; i < movies.size(); i++) {
                if (movies.get(i).getId().equals(movie.getId())) {
                    movies.set(i, movie);
                    return;
                }
            }
        }
        movies.add(movie);
    }

    // ==========================================
    // FIND MOVIE BY ID
    // ==========================================
    public Movie findById(Long id) {
        if (id == null) return null;
        for (Movie movie : movies) {
            if (movie.getId() != null && movie.getId().equals(id)) {
                return movie;
            }
        }
        return null;
    }

    // ==========================================
    // UPDATE MOVIE
    // ==========================================
    public synchronized boolean updateMovie(Movie updatedMovie) {
        if (updatedMovie == null || updatedMovie.getId() == null) return false;
        Movie existing = findById(updatedMovie.getId());
        if (existing != null) {
            existing.setTitle(updatedMovie.getTitle());
            existing.setGenre(updatedMovie.getGenre());
            existing.setDescription(updatedMovie.getDescription());
            existing.setPosterUrl(updatedMovie.getPosterUrl());
            existing.setRating(updatedMovie.getRating());
            existing.setLanguage(updatedMovie.getLanguage());
            existing.setDuration(updatedMovie.getDuration());
            existing.setReleaseDate(updatedMovie.getReleaseDate());
            existing.setStatus(updatedMovie.getStatus());
            return true;
        }
        return false;
    }

    // ==========================================
    // DELETE MOVIE
    // ==========================================
    public synchronized boolean deleteById(Long id) {
        if (id == null) return false;
        return movies.removeIf(movie -> movie.getId() != null && movie.getId().equals(id));
    }
}