package com.cinebook.cinebookingsystem.repository;

import com.cinebook.cinebookingsystem.model.SupportTicket;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class SupportTicketRepository {

    private final List<SupportTicket> tickets = new ArrayList<>();

    public SupportTicketRepository() {
        SupportTicket ticket = new SupportTicket();
        ticket.setId(1L);
        ticket.setCustomerName("John");
        ticket.setEmail("john@gmail.com");
        ticket.setSubject("Booking Issue");
        ticket.setMessage("I cannot select my preferred seat.");
        ticket.setStatus("OPEN");
        ticket.setResponse("");
        tickets.add(ticket);
    }

    public List<SupportTicket> findAll() {
        return new ArrayList<>(tickets);
    }

    public Optional<SupportTicket> findById(Long id) {
        if (id == null) {
            return Optional.empty();
        }
        return tickets.stream()
                .filter(ticket -> id.equals(ticket.getId()))
                .findFirst();
    }

    public List<SupportTicket> findByUserId(Long userId) {
        if (userId == null) {
            return new ArrayList<>();
        }
        return tickets.stream()
                .filter(ticket -> userId.equals(ticket.getUserId()))
                .collect(Collectors.toList());
    }

    public SupportTicket save(SupportTicket ticket) {
        if (ticket == null) {
            return null;
        }

        if (ticket.getId() == null) {
            long newId = tickets.stream()
                    .map(SupportTicket::getId)
                    .filter(id -> id != null)
                    .mapToLong(Long::longValue)
                    .max()
                    .orElse(0L) + 1L;
            ticket.setId(newId);
            tickets.add(ticket);
            return ticket;
        }

        Optional<SupportTicket> existingOptional = findById(ticket.getId());
        if (existingOptional.isPresent()) {
            copyValues(existingOptional.get(), ticket);
        } else {
            tickets.add(ticket);
        }
        return ticket;
    }

    public boolean update(SupportTicket updatedTicket) {
        if (updatedTicket == null || updatedTicket.getId() == null) {
            return false;
        }
        Optional<SupportTicket> existing = findById(updatedTicket.getId());
        if (existing.isEmpty()) {
            return false;
        }
        copyValues(existing.get(), updatedTicket);
        return true;
    }

    public boolean deleteById(Long id) {
        if (id == null) {
            return false;
        }
        return tickets.removeIf(ticket -> id.equals(ticket.getId()));
    }

    private void copyValues(SupportTicket target, SupportTicket source) {
        target.setUserId(source.getUserId());
        target.setCustomerName(source.getCustomerName());
        target.setEmail(source.getEmail());
        target.setSubject(source.getSubject());
        target.setMessage(source.getMessage());
        target.setStatus(source.getStatus());
        target.setResponse(source.getResponse());
    }
}
