package com.cinebook.cinebookingsystem.controller;

import com.cinebook.cinebookingsystem.config.ValidationConfig;
import com.cinebook.cinebookingsystem.model.Booking;
import com.cinebook.cinebookingsystem.model.Payment;
import com.cinebook.cinebookingsystem.repository.PaymentRepository;
import com.cinebook.cinebookingsystem.service.BookingService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class PaymentController {

    private final BookingService bookingService;
    private final PaymentRepository paymentRepository;

    public PaymentController(
            BookingService bookingService,
            PaymentRepository paymentRepository) {
        this.bookingService = bookingService;
        this.paymentRepository = paymentRepository;
    }

    // ==========================================
    // PAYMENT PAGE (DEMO PAYMENT GATEWAY)
    // ==========================================
    @GetMapping("/payment")
    public String paymentPage(
            @RequestParam Long bookingId,
            @RequestParam(required = false) String error,
            Model model) {

        Booking booking = bookingService.findBookingById(bookingId);

        if (booking == null) {
            model.addAttribute("error", "Booking not found or session has expired.");
            return "payment";
        }

        if ("PAID".equalsIgnoreCase(booking.getStatus()) || "CONFIRMED".equalsIgnoreCase(booking.getStatus())) {
            return "redirect:/payment-success?bookingId=" + bookingId;
        }

        if ("CANCELLED".equalsIgnoreCase(booking.getStatus()) || "EXPIRED".equalsIgnoreCase(booking.getStatus())) {
            model.addAttribute("error", "This booking seat lock has expired or was cancelled. Please book again.");
            model.addAttribute("booking", booking);
            return "payment";
        }

        model.addAttribute("booking", booking);
        if (error != null) {
            model.addAttribute("error", error);
        }

        return "payment";
    }

    // ==========================================
    // PROCESS MOCK PAYMENT
    // ==========================================
    @PostMapping("/payment/process")
    public String processPayment(
            @RequestParam Long bookingId,
            @RequestParam String paymentMethod,
            @RequestParam(required = false) String cardNumber,
            @RequestParam(required = false) String cardHolder,
            @RequestParam(required = false) String cardExpiry,
            @RequestParam(required = false) String cardCvv,
            @RequestParam(required = false) String upiId,
            @RequestParam(required = false, defaultValue = "false") boolean simulateFailure,
            Model model) {

        Booking booking = bookingService.findBookingById(bookingId);
        if (booking == null) {
            model.addAttribute("error", "Booking record not found.");
            return "payment";
        }

        // Check if seat lock expired
        long now = System.currentTimeMillis();
        if (booking.getLockExpiryTime() > 0 && booking.getLockExpiryTime() <= now) {
            booking.setStatus("EXPIRED");
            model.addAttribute("error", "Your seat reservation time expired. Please reselect your seats.");
            model.addAttribute("booking", booking);
            return "payment";
        }

        // Check for simulated failure trigger (e.g. user toggled failure or card ends with 0000)
        if (simulateFailure || (cardNumber != null && cardNumber.replaceAll("\\s+", "").endsWith("0000"))) {
            model.addAttribute("error", "Demo Payment Declined: Transaction simulation rejected by issuer (Test Failure Mode). Please retry.");
            model.addAttribute("booking", booking);
            return "payment";
        }

        // Validate method-specific fields
        if ("CARD".equalsIgnoreCase(paymentMethod)) {
            String cleanCard = cardNumber != null ? cardNumber.replaceAll("[^0-9]", "") : "";
            if (cleanCard.length() < 15 || cleanCard.length() > 19) {
                model.addAttribute("error", "Please enter a valid 16-digit card number.");
                model.addAttribute("booking", booking);
                return "payment";
            }
            if (cardHolder == null || cardHolder.trim().length() < 2) {
                model.addAttribute("error", "Please enter the name on the card.");
                model.addAttribute("booking", booking);
                return "payment";
            }
            if (cardCvv == null || cardCvv.trim().length() < 3) {
                model.addAttribute("error", "Please enter a valid 3-digit CVV.");
                model.addAttribute("booking", booking);
                return "payment";
            }
        } else if ("UPI".equalsIgnoreCase(paymentMethod)) {
            if (upiId == null || !upiId.contains("@") || upiId.trim().length() < 5) {
                model.addAttribute("error", "Please enter a valid UPI Virtual ID (e.g. name@okhdfcbank).");
                model.addAttribute("booking", booking);
                return "payment";
            }
        }

        // ================= SUCCESSFUL PAYMENT SIMULATION =================
        Payment payment = new Payment();
        payment.setBookingId(booking.getId());
        payment.setAmount(booking.getPrice());
        payment.setPaymentMethod(paymentMethod.toUpperCase());
        payment.setStatus("SUCCESS");
        paymentRepository.save(payment);

        // Update booking status
        booking.setStatus("PAID");
        booking.setPaymentMethod(paymentMethod.toUpperCase());
        booking.setLockExpiryTime(0);

        return "redirect:/payment-success?bookingId=" + booking.getId();
    }

    // ==========================================
    // PAYMENT SUCCESS & TICKET CONFIRMATION
    // ==========================================
    @GetMapping("/payment-success")
    public String paymentSuccess(
            @RequestParam Long bookingId,
            Model model) {

        Booking booking = bookingService.findBookingById(bookingId);
        if (booking == null) {
            return "redirect:/";
        }

        Payment payment = paymentRepository.findAll().stream()
                .filter(p -> p.getBookingId() != null && p.getBookingId().equals(bookingId))
                .findFirst()
                .orElse(null);

        if (payment == null) {
            payment = new Payment();
            payment.setBookingId(bookingId);
            payment.setAmount(booking.getPrice());
            payment.setPaymentMethod(booking.getPaymentMethod() != null ? booking.getPaymentMethod() : "CARD");
            payment.setStatus("SUCCESS");
        }

        model.addAttribute("booking", booking);
        model.addAttribute("payment", payment);

        return "payment-success";
    }
}