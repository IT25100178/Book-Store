package com.cinebook.cinebookingsystem.service;

import com.cinebook.cinebookingsystem.model.Promotion;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MarketingService {

    private final List<Promotion> promotions =
            new ArrayList<>();

    public MarketingService() {

        Promotion promotion = new Promotion();

        promotion.setId(1L);
        promotion.setTitle("Weekend Movie Offer");
        promotion.setDescription(
                "Get special discounts on weekend movie bookings."
        );
        promotion.setStartDate("2026-09-20");
        promotion.setEndDate("2026-09-30");
        promotion.setStatus("ACTIVE");

        promotions.add(promotion);
    }

    // ==========================================
    // GET ALL PROMOTIONS
    // ==========================================

    public List<Promotion> getAllPromotions() {
        return promotions;
    }

    // ==========================================
    // FIND PROMOTION BY ID
    // ==========================================

    public Promotion getPromotionById(Long id) {

        for (Promotion promotion : promotions) {

            if (promotion.getId() != null
                    && promotion.getId().equals(id)) {

                return promotion;
            }
        }

        return null;
    }

    // ==========================================
    // ADD PROMOTION
    // ==========================================

    public void addPromotion(Promotion promotion) {

        if (promotion.getId() == null) {

            promotion.setId(
                    (long) promotions.size() + 1
            );
        }

        if (promotion.getStatus() == null
                || promotion.getStatus().isEmpty()) {

            promotion.setStatus("ACTIVE");
        }

        promotions.add(promotion);
    }

    // ==========================================
    // UPDATE PROMOTION
    // ==========================================

    public boolean updatePromotion(
            Promotion updatedPromotion) {

        Promotion existing =
                getPromotionById(
                        updatedPromotion.getId()
                );

        if (existing == null) {
            return false;
        }

        existing.setTitle(
                updatedPromotion.getTitle()
        );

        existing.setDescription(
                updatedPromotion.getDescription()
        );

        existing.setStartDate(
                updatedPromotion.getStartDate()
        );

        existing.setEndDate(
                updatedPromotion.getEndDate()
        );

        existing.setStatus(
                updatedPromotion.getStatus()
        );

        return true;
    }

    // ==========================================
    // DELETE PROMOTION
    // ==========================================

    public boolean deletePromotion(Long id) {

        return promotions.removeIf(
                promotion ->
                        promotion.getId() != null
                                && promotion.getId()
                                .equals(id)
        );
    }
}