package com.cinebook.cinebookingsystem.config;

import org.springframework.stereotype.Component;
import java.util.List;
import java.util.regex.Pattern;

/**
 * ============================================================================
 * VALIDATION & BUSINESS CONFIGURATION SECTION
 * ============================================================================
 * You can customize and adjust all validation rules, regex patterns,
 * seat layout pricing, convenience fees, and transaction limits directly here.
 */
@Component
public class ValidationConfig {

    // ==========================================
    // 1. EMAIL VALIDATION RULES
    // ==========================================
    /**
     * Standard email regex pattern.
     */
    public static final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
    public static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);

    /**
     * Allowed email domains.
     * Leave empty to allow all valid email domains.
     * Example: List.of("gmail.com", "yahoo.com", "outlook.com")
     */
    public static final List<String> ALLOWED_EMAIL_DOMAINS = List.of(
            // Optional: specify domains or leave empty for open registration
    );

    // ==========================================
    // 2. MOBILE NUMBER FORMAT
    // ==========================================
    /**
     * Mobile number regex: accepts 10-digit formats (e.g., 0771234567 or +94771234567).
     */
    public static final String MOBILE_REGEX = "^(?:\\+94|0)?7[0-9]{8}$";
    public static final Pattern MOBILE_PATTERN = Pattern.compile(MOBILE_REGEX);
    public static final int MOBILE_EXACT_DIGITS = 10;

    // ==========================================
    // 3. PASSWORD RULES
    // ==========================================
    public static final int PASSWORD_MIN_LENGTH = 8;
    public static final int PASSWORD_MAX_LENGTH = 64;
    public static final boolean REQUIRE_LETTERS = true;
    public static final boolean REQUIRE_DIGITS = true;
    public static final boolean REQUIRE_SPECIAL_CHAR = false; // Set to true if special symbol is required

    // ==========================================
    // 4. USER PROFILE RULES
    // ==========================================
    public static final int NAME_MIN_LENGTH = 2;
    public static final int NAME_MAX_LENGTH = 60;
    public static final int USERNAME_MIN_LENGTH = 3;
    public static final int USERNAME_MAX_LENGTH = 30;

    // ==========================================
    // 5. MOVIE VALIDATION RULES
    // ==========================================
    public static final int MOVIE_TITLE_MIN_LENGTH = 1;
    public static final int MOVIE_TITLE_MAX_LENGTH = 100;
    public static final double MOVIE_RATING_MIN = 0.0;
    public static final double MOVIE_RATING_MAX = 10.0;

    // ==========================================
    // 6. THEATRE & CITY RULES
    // ==========================================
    public static final int THEATRE_NAME_MIN_LENGTH = 2;
    public static final int THEATRE_MIN_CAPACITY = 20;
    public static final int THEATRE_MAX_CAPACITY = 1000;
    public static final int THEATRE_MIN_SCREENS = 1;
    public static final int THEATRE_MAX_SCREENS = 20;
    public static final int THEATRE_MIN_SEATS_PER_SCREEN = 10;

    // ==========================================
    // 7. SEAT LAYOUT & BOOKING LIMITS
    // ==========================================
    /** Maximum seats a user can book in a single transaction */
    public static final int MAX_SEATS_PER_BOOKING = 6;
    public static final int MIN_SEATS_PER_BOOKING = 1;

    /** Seat lock duration in milliseconds (5 minutes) */
    public static final long SEAT_LOCK_DURATION_MS = 5 * 60 * 1000;

    // ==========================================
    // 8. PRICING & TAX CONFIGURATION
    // ==========================================
    /** Standard seat price in LKR */
    public static final double STANDARD_SEAT_PRICE = 1000.00;

    /** Premium / VIP seat price in LKR */
    public static final double PREMIUM_SEAT_PRICE = 1500.00;

    /** Convenience fee per ticket in LKR */
    public static final double CONVENIENCE_FEE_PER_TICKET = 50.00;

    /** Tax rate (5% = 0.05) */
    public static final double TAX_RATE = 0.05;

    // ==========================================
    // 9. PAYMENT VALIDATION RULES (MOCK)
    // ==========================================
    /** Card number length check (16 digits for Visa/Mastercard) */
    public static final String CARD_REGEX = "^[0-9]{16}$";
    /** CVV check (3 digits) */
    public static final String CVV_REGEX = "^[0-9]{3}$";
    /** UPI Virtual Payment Address regex */
    public static final String UPI_REGEX = "^[a-zA-Z0-9.\\-_]{2,49}@[a-zA-Z]{2,}$";

    // ==========================================
    // HELPER VALIDATION METHODS
    // ==========================================
    public static boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) return false;
        String trimmed = email.trim();
        if (!EMAIL_PATTERN.matcher(trimmed).matches()) return false;
        if (!ALLOWED_EMAIL_DOMAINS.isEmpty()) {
            String domain = trimmed.substring(trimmed.indexOf("@") + 1).toLowerCase();
            return ALLOWED_EMAIL_DOMAINS.contains(domain);
        }
        return true;
    }

    public static boolean isValidMobile(String mobile) {
        if (mobile == null || mobile.trim().isEmpty()) return false;
        String digits = mobile.trim().replaceAll("[^0-9]", "");
        return digits.length() == MOBILE_EXACT_DIGITS || digits.length() == 11;
    }

    public static boolean isValidPassword(String password) {
        if (password == null || password.length() < PASSWORD_MIN_LENGTH || password.length() > PASSWORD_MAX_LENGTH) {
            return false;
        }
        if (REQUIRE_LETTERS && !password.matches(".*[A-Za-z].*")) return false;
        if (REQUIRE_DIGITS && !password.matches(".*\\d.*")) return false;
        if (REQUIRE_SPECIAL_CHAR && !password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*")) return false;
        return true;
    }

    public static double calculateSeatPrice(String seatNumber) {
        if (seatNumber == null || seatNumber.trim().isEmpty()) {
            return STANDARD_SEAT_PRICE;
        }
        char row = Character.toUpperCase(seatNumber.trim().charAt(0));
        if (row == 'D' || row == 'E') {
            return PREMIUM_SEAT_PRICE;
        }
        return STANDARD_SEAT_PRICE;
    }
}
