package com.cinebook.cinebookingsystem.repository;

import com.cinebook.cinebookingsystem.model.User;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class UserRepository {

    private final List<User> users = new ArrayList<>();

    public UserRepository() {
        addDemo(1L, "customer@moviebook.com", "Password123",
                "Demo Customer", "customer", "CUSTOMER", true);

        addDemo(2L, "admin@moviebook.com", "Admin123!",
                "System Admin", "admin", "ADMIN", true);

        addDemo(3L, "owner@moviebook.com", "Owner123!",
                "Demo Cinema Owner", "owner", "OWNER", true);
    }

    private void addDemo(Long id, String email, String password, String name,
                          String username, String role, boolean verified) {
        User user = new User();

        user.setId(id);
        user.setEmail(email);
        user.setPassword(password);
        user.setName(name);
        user.setUsername(username);
        user.setRole(role);
        user.setStatus("ACTIVE");
        user.setVerified(verified);

        users.add(user);
    }

    public synchronized User save(User user) {
        if (user.getId() == null) {
            long maxId = users.stream()
                    .mapToLong(u -> u.getId() == null ? 0 : u.getId())
                    .max()
                    .orElse(0);

            user.setId(maxId + 1);
            users.add(user);

            return user;
        }

        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId().equals(user.getId())) {
                users.set(i, user);
                return user;
            }
        }

        users.add(user);
        return user;
    }

    public Optional<User> findById(Long id) {
        if (id == null) {
            return Optional.empty();
        }

        return users.stream()
                .filter(u -> id.equals(u.getId()))
                .findFirst();
    }

    public Optional<User> findByEmail(String email) {
        if (email == null) {
            return Optional.empty();
        }

        return users.stream()
                .filter(u -> email.equalsIgnoreCase(u.getEmail()))
                .findFirst();
    }

    public Optional<User> findByUsername(String username) {
        if (username == null) {
            return Optional.empty();
        }

        return users.stream()
                .filter(u -> username.equalsIgnoreCase(u.getUsername()))
                .findFirst();
    }

    public Optional<User> findByUsernameOrEmail(String value) {
        if (value == null) {
            return Optional.empty();
        }

        return users.stream()
                .filter(u -> value.equalsIgnoreCase(u.getUsername())
                        || value.equalsIgnoreCase(u.getEmail()))
                .findFirst();
    }

    public List<User> findAll() {
        return new ArrayList<>(users);
    }
}