package com.cinebook.cinebookingsystem;

import com.cinebook.cinebookingsystem.config.ValidationConfig;
import com.cinebook.cinebookingsystem.model.Booking;
import com.cinebook.cinebookingsystem.model.Movie;
import com.cinebook.cinebookingsystem.model.User;
import com.cinebook.cinebookingsystem.repository.BookingRepository;
import com.cinebook.cinebookingsystem.repository.MovieRepository;
import com.cinebook.cinebookingsystem.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class CineBookApplicationTests {

    @Autowired
    private MovieRepository movieRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Test
    void contextLoads() {
        assertNotNull(movieRepository);
        assertNotNull(userRepository);
        assertNotNull(bookingRepository);
    }

    @Test
    void testPreloadedMovies() {
        List<Movie> movies = movieRepository.findAll();

        assertTrue(
                movies.size() >= 8,
                "Expected at least 8 preloaded movies"
        );

        for (Movie m : movies) {
            assertNotNull(m.getId());
            assertNotNull(m.getTitle());
            assertFalse(m.getTitle().trim().isEmpty());
            assertNotNull(m.getPosterUrl());
        }
    }

    @Test
    void testDemoUsersExist() {

        Optional<User> customerResult =
                userRepository.findByUsernameOrEmail("customer@moviebook.com");

        assertTrue(
                customerResult.isPresent(),
                "Demo customer account should exist"
        );

        User customer = customerResult.get();

        assertEquals("Password123", customer.getPassword());
        assertEquals("CUSTOMER", customer.getRole());

        Optional<User> adminResult =
                userRepository.findByUsernameOrEmail("admin@moviebook.com");

        assertTrue(
                adminResult.isPresent(),
                "Demo admin account should exist"
        );

        User admin = adminResult.get();

        assertEquals("Admin123!", admin.getPassword());
        assertEquals("ADMIN", admin.getRole());
    }

    @Test
    void testValidationConfigPricingAndRules() {

        // Standard seat
        assertEquals(
                1000.0,
                ValidationConfig.calculateSeatPrice("A1")
        );

        assertEquals(
                1000.0,
                ValidationConfig.calculateSeatPrice("B5")
        );

        assertEquals(
                1000.0,
                ValidationConfig.calculateSeatPrice("C8")
        );

        // VIP seat
        assertEquals(
                1500.0,
                ValidationConfig.calculateSeatPrice("D1")
        );

        assertEquals(
                1500.0,
                ValidationConfig.calculateSeatPrice("E8")
        );

        // Validation regexes
        assertTrue(
                ValidationConfig.isValidEmail("test@example.com")
        );

        assertFalse(
                ValidationConfig.isValidEmail("invalid-email")
        );

        assertTrue(
                ValidationConfig.isValidMobile("0771234567")
        );

        assertFalse(
                ValidationConfig.isValidMobile("12345")
        );

        assertTrue(
                ValidationConfig.isValidPassword("Password123")
        );

        assertFalse(
                ValidationConfig.isValidPassword("short")
        );
    }

    @Test
    void testBookingMultiSeatOperations() {

        Booking b = new Booking();

        b.setMovieId(99L);
        b.setMovieTitle("Avatar");
        b.setTheatre("Majestic Cineplex");
        b.setDate("2026-09-25");
        b.setShowTime("07:00 PM");
        b.setSeatNumber("C1, C2");
        b.setPrice(2150.0);
        b.setUserEmail("customer@moviebook.com");
        b.setStatus("PAID");

        bookingRepository.save(b);

        // Check booked seats for show
        List<String> bookedSeats =
                bookingRepository.getBookedSeatsForShow(
                        99L,
                        "Majestic Cineplex",
                        "2026-09-25",
                        "07:00 PM"
                );

        assertTrue(bookedSeats.contains("C1"));
        assertTrue(bookedSeats.contains("C2"));
        assertFalse(bookedSeats.contains("A5"));
    }
}